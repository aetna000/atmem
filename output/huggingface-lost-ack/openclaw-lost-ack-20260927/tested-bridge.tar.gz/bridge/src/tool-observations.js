import { createHash } from "node:crypto";
import { toolErrorReason } from "./tool-errors.js";
const CACHE_KEY = Symbol.for("atmem.tool-observation-cache.v1");
const sharedCache = globalThis;
const cache = sharedCache[CACHE_KEY] ??= new Map();
/** Some hosts deny run-context writes from tool hooks after registry reload.
 * Keep a bounded content-minimized process fallback, isolated by installation config.
 */
export function observationContext(host, scope) {
    const keyFor = (runId, namespace) => JSON.stringify([scope, runId, namespace]);
    const sweep = () => {
        for (const [key, entry] of cache)
            if (entry.expires <= Date.now())
                cache.delete(key);
        while (cache.size >= 2048)
            cache.delete(cache.keys().next().value);
    };
    return {
        setRunContext(patch) {
            sweep();
            cache.set(keyFor(patch.runId, patch.namespace), { value: structuredClone(patch.value), expires: Date.now() + 600_000 });
            try {
                host?.setRunContext(patch);
            }
            catch { /* Process fallback remains bounded. */ }
            return true;
        },
        getRunContext(params) {
            sweep();
            const entry = cache.get(keyFor(params.runId, params.namespace));
            if (entry)
                return structuredClone(entry.value);
            try {
                return host?.getRunContext(params);
            }
            catch {
                return undefined;
            }
        },
    };
}
const INDEX = "atmem-tool-observations-v1";
const namespace = (id) => INDEX + "-" + createHash("sha256").update(id).digest("hex");
/** The CLI exposes its native names; the request hook exposes OpenClaw names. */
function canonical(name) {
    const unwrapped = name.replace(/^mcp__openclaw__/, "");
    return { Read: "read", Bash: "exec" }[unwrapped] ?? unwrapped;
}
/** Stores scope, names, digests and redacted error diagnostics in bounded ephemeral context. */
export class ToolObservations {
    access;
    digest;
    constructor(access, digest) {
        this.access = access;
        this.digest = digest;
    }
    request(name, id, ctx) {
        if (!id || !ctx.runId || !ctx.agentId || !ctx.sessionId || !ctx.sessionKey)
            return;
        const runId = ctx.runId;
        const ids = this.access.getRunContext({ runId, namespace: INDEX }) ?? [];
        if (ids.includes(id) || ids.length >= 256)
            return;
        // Never store the full hook context: it may contain host config/credentials.
        const scope = { runId, agentId: ctx.agentId, sessionId: ctx.sessionId, sessionKey: ctx.sessionKey };
        if (this.access.setRunContext({ runId, namespace: namespace(id), value: { ctx: scope, name, callId: id } })) {
            this.access.setRunContext({ runId, namespace: INDEX, value: [...ids, id] });
        }
    }
    completed(id, ctx) {
        if (!id || !ctx.runId)
            return;
        const key = { runId: ctx.runId, namespace: namespace(id) };
        const saved = this.access.getRunContext(key);
        if (saved && saved.ctx.sessionId === ctx.sessionId && saved.ctx.sessionKey === ctx.sessionKey && saved.ctx.agentId === ctx.agentId) {
            this.access.setRunContext({ ...key, value: { ...saved, hookCompleted: true } });
        }
    }
    observe(event) {
        const d = event.data;
        if (event.stream !== "tool" || d.phase !== "result" || typeof d.toolCallId !== "string" ||
            typeof d.name !== "string" || typeof d.isError !== "boolean" ||
            !Object.hasOwn(d, "result") || d.incomplete === true || d.synthetic === true)
            return;
        const key = { runId: event.runId, namespace: namespace(d.toolCallId) };
        const saved = this.access.getRunContext(key);
        if (!saved || event.sessionKey !== saved.ctx.sessionKey ||
            (event.sessionId !== undefined && event.sessionId !== saved.ctx.sessionId) ||
            (event.agentId !== undefined && event.agentId !== saved.ctx.agentId) ||
            canonical(d.name) !== canonical(saved.name))
            return;
        const result = { digest: this.digest(d.result), error: d.isError,
            reason: d.isError ? toolErrorReason(d.error ?? d.result) : undefined,
            errorDigest: d.isError && d.error !== undefined ? this.digest(d.error) : undefined };
        const conflict = saved.conflict || (saved.result !== undefined &&
            (saved.result.digest !== result.digest || saved.result.error !== result.error ||
                saved.result.errorDigest !== result.errorDigest));
        this.access.setRunContext({ ...key, value: { ...saved, result, conflict } });
    }
    async flush(ctx, record) {
        if (!ctx.runId)
            return;
        const runId = ctx.runId;
        const ids = this.access.getRunContext({ runId, namespace: INDEX }) ?? [];
        for (const id of ids) {
            const key = { runId, namespace: namespace(id) };
            const saved = this.access.getRunContext(key);
            if (saved && !saved.hookCompleted && !saved.conflict && saved.result &&
                saved.ctx.sessionKey === ctx.sessionKey && saved.ctx.sessionId === ctx.sessionId && saved.ctx.agentId === ctx.agentId) {
                await record(saved);
                this.access.setRunContext({ ...key, value: { ...saved, hookCompleted: true } });
            }
        }
    }
}
