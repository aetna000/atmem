import { createCipheriv, createDecipheriv, randomBytes, randomUUID } from "node:crypto";
import { chmod, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
const SPOOL_AAD = Buffer.from("atmem-openclaw-encrypted-execution-spool-v2", "utf8");
/** A bounded, atomic local spool. Removal requires a durable terminal receipt. */
export class ExecutionSpool {
    filePath;
    maxPending;
    maxAgeMs;
    keyPath;
    state = null;
    serial = Promise.resolve();
    constructor(filePath, maxPending = 2048, maxAgeMs = 7 * 24 * 60 * 60 * 1000, keyPath = path.resolve(path.dirname(filePath), "..", ".atmem-evidence-keys", "openclaw-spool.key")) {
        this.filePath = filePath;
        this.maxPending = maxPending;
        this.maxAgeMs = maxAgeMs;
        this.keyPath = keyPath;
        if (maxPending < 2)
            throw new Error("execution spool capacity must be at least 2");
    }
    enqueue(value) {
        return this.exclusive(async () => {
            const state = await this.load();
            this.expirePending(state, Date.now() - this.maxAgeMs);
            const envelope = {
                ...value,
                event_id: randomUUID(),
                producer_instance_id: state.producerInstanceId,
                producer_epoch: state.producerEpoch,
                producer_sequence: state.nextSequence++,
                event_time: new Date().toISOString(),
            };
            state.pending.push(envelope);
            if (state.pending.length > this.maxPending) {
                const dropped = state.pending.length - this.maxPending + 1;
                const removed = state.pending.splice(0, dropped);
                state.pending.unshift({
                    event_type: "capture.gap",
                    run_id: String(envelope.run_id ?? "capture-spool"),
                    payload: {
                        reason: "spool_capacity_exceeded",
                        dropped_count: removed.length,
                        first_sequence: removed[0]?.producer_sequence,
                        last_sequence: removed.at(-1)?.producer_sequence,
                    },
                    event_id: randomUUID(),
                    producer_instance_id: state.producerInstanceId,
                    producer_epoch: state.producerEpoch,
                    producer_sequence: state.nextSequence++,
                    event_time: new Date().toISOString(),
                });
            }
            await this.persist(state);
            return envelope;
        });
    }
    flush(send) {
        return this.exclusive(async () => {
            const state = await this.load();
            let acknowledged = 0;
            while (state.pending.length) {
                const result = await send(state.pending[0]);
                const receipt = result;
                const accepted = receipt?.durably_accepted === true;
                const classifiedConflict = receipt?.decision === "conflict" &&
                    receipt?.durably_classified === true;
                if (!accepted && !classifiedConflict) {
                    throw new Error("AtMem did not confirm a durable terminal execution-event decision");
                }
                state.pending.shift();
                acknowledged += 1;
                await this.persist(state);
            }
            return acknowledged;
        });
    }
    async snapshot() {
        return this.exclusive(async () => ({ ...(await this.load()), pending: [...(await this.load()).pending] }));
    }
    exclusive(action) {
        const next = this.serial.then(action, action);
        this.serial = next.then(() => undefined, () => undefined);
        return next;
    }
    async load() {
        if (this.state)
            return this.state;
        try {
            const wrapper = JSON.parse(await readFile(this.filePath, "utf8"));
            if (wrapper.format !== "atmem-openclaw-encrypted-execution-spool-v2") {
                throw new Error("unsupported execution spool format");
            }
            const key = await this.loadOrCreateKey();
            const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(wrapper.nonce, "base64"));
            decipher.setAAD(SPOOL_AAD);
            decipher.setAuthTag(Buffer.from(wrapper.tag, "base64"));
            const plain = Buffer.concat([
                decipher.update(Buffer.from(wrapper.ciphertext, "base64")), decipher.final(),
            ]).toString("utf8");
            const value = JSON.parse(plain);
            if (value.format !== "atmem-openclaw-execution-spool-v1" || !Array.isArray(value.pending)) {
                throw new Error("unsupported decrypted execution spool state");
            }
            // Pending events retain their original epoch. New events get a fresh
            // epoch and sequence after every plugin process start.
            this.state = {
                ...value,
                producerEpoch: randomUUID(),
                nextSequence: 1,
            };
        }
        catch (error) {
            const code = error.code;
            if (code !== "ENOENT")
                throw error;
            this.state = {
                format: "atmem-openclaw-execution-spool-v1",
                producerInstanceId: randomUUID(),
                producerEpoch: randomUUID(),
                nextSequence: 1,
                pending: [],
            };
        }
        await this.persist(this.state);
        return this.state;
    }
    async persist(state) {
        await mkdir(path.dirname(this.filePath), { recursive: true, mode: 0o700 });
        const key = await this.loadOrCreateKey();
        const nonce = randomBytes(12);
        const cipher = createCipheriv("aes-256-gcm", key, nonce);
        cipher.setAAD(SPOOL_AAD);
        const ciphertext = Buffer.concat([
            cipher.update(JSON.stringify(state), "utf8"), cipher.final(),
        ]);
        const wrapper = {
            format: "atmem-openclaw-encrypted-execution-spool-v2",
            suite: "AES-256-GCM",
            nonce: nonce.toString("base64"),
            ciphertext: ciphertext.toString("base64"),
            tag: cipher.getAuthTag().toString("base64"),
        };
        const temporary = `${this.filePath}.${process.pid}.${randomUUID()}.tmp`;
        await writeFile(temporary, `${JSON.stringify(wrapper)}\n`, { encoding: "utf8", mode: 0o600 });
        await rename(temporary, this.filePath);
        await chmod(this.filePath, 0o600);
    }
    async loadOrCreateKey() {
        await mkdir(path.dirname(this.keyPath), { recursive: true, mode: 0o700 });
        try {
            const encoded = (await readFile(this.keyPath, "utf8")).trim();
            const key = Buffer.from(encoded, "base64");
            if (key.length !== 32)
                throw new Error("execution spool key must be 256 bits");
            return key;
        }
        catch (error) {
            if (error.code !== "ENOENT")
                throw error;
            const key = randomBytes(32);
            await writeFile(this.keyPath, `${key.toString("base64")}\n`, {
                encoding: "utf8", mode: 0o600, flag: "wx",
            });
            await chmod(this.keyPath, 0o600);
            return key;
        }
    }
    expirePending(state, cutoff) {
        const expired = state.pending.filter(event => Date.parse(event.event_time) < cutoff);
        if (!expired.length)
            return;
        state.pending = state.pending.filter(event => Date.parse(event.event_time) >= cutoff);
        state.pending.unshift({
            event_type: "capture.gap",
            run_id: String(expired.at(-1)?.run_id ?? "capture-spool"),
            payload: {
                reason: "spool_retention_expired",
                dropped_count: expired.length,
                first_sequence: expired[0].producer_sequence,
                last_sequence: expired.at(-1)?.producer_sequence,
            },
            event_id: randomUUID(),
            producer_instance_id: state.producerInstanceId,
            producer_epoch: state.producerEpoch,
            producer_sequence: state.nextSequence++,
            event_time: new Date().toISOString(),
        });
    }
}
