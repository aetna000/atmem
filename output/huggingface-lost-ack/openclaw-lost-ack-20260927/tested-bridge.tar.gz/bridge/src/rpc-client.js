/**
 * Newline-delimited JSON-RPC 2.0 client for the `atmem mcp` stdio server.
 *
 * The child process is spawned lazily on first call, the MCP initialize
 * handshake runs once, and calls are matched to responses by request id.
 * If the child dies it is respawned on the next call.
 */
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
export class AtmemClient {
    options;
    child = null;
    reader = null;
    pending = new Map();
    nextId = 1;
    initialized = null;
    idleTimer = null;
    toolNames = null;
    constructor(options) {
        this.options = options;
    }
    /** Verify that the engine starts and completes the MCP handshake. */
    async connect() {
        try {
            this.cancelIdleClose();
            await this.ensureInitialized();
        }
        finally {
            this.scheduleIdleClose();
        }
    }
    /** Call an MCP tool; returns the parsed JSON payload of the text block. */
    async callTool(name, args, timeoutMs) {
        try {
            this.cancelIdleClose();
            await this.ensureInitialized();
            const result = (await this.request("tools/call", { name, arguments: args }, timeoutMs));
            const text = result?.content?.[0]?.text ?? "";
            if (result?.isError) {
                throw new Error(`atmem tool ${name} failed: ${text}`);
            }
            try {
                return JSON.parse(text);
            }
            catch {
                return text;
            }
        }
        finally {
            this.scheduleIdleClose();
        }
    }
    /** Discover optional server capabilities without assuming a package version. */
    async hasTool(name, timeoutMs) {
        try {
            this.cancelIdleClose();
            if (this.toolNames === null) {
                await this.ensureInitialized();
                const result = (await this.request("tools/list", {}, timeoutMs));
                this.toolNames = new Set((result?.tools ?? [])
                    .map((tool) => String(tool.name ?? ""))
                    .filter(Boolean));
            }
            return this.toolNames.has(name);
        }
        finally {
            this.scheduleIdleClose();
        }
    }
    close() {
        this.cancelIdleClose();
        if (this.child) {
            this.child.stdin.end();
            this.child.kill();
        }
        this.teardown(new Error("client closed"));
    }
    cancelIdleClose() {
        if (this.idleTimer)
            clearTimeout(this.idleTimer);
        this.idleTimer = null;
    }
    scheduleIdleClose() {
        this.cancelIdleClose();
        const timeout = this.options.idleTimeoutMs ?? 250;
        this.idleTimer = setTimeout(() => this.close(), timeout);
    }
    async ensureInitialized() {
        if (!this.child || this.child.exitCode !== null) {
            this.startChild();
            this.initialized = this.handshake();
        }
        await this.initialized;
    }
    startChild() {
        const { command, args } = this.options;
        this.options.log?.(`[atmem] spawning: ${command} ${args.join(" ")}`);
        const child = spawn(command, args, { stdio: ["pipe", "pipe", "pipe"] });
        this.child = child;
        this.reader = createInterface({ input: child.stdout });
        this.reader.on("line", (line) => this.onLine(line));
        child.stderr.on("data", (chunk) => {
            const text = chunk.toString().trim();
            if (text)
                this.options.logError?.(`[atmem stderr] ${text}`);
        });
        child.on("exit", (code) => {
            this.options.logError?.(`[atmem] server exited (code ${code})`);
            this.teardown(new Error(`atmem server exited (code ${code})`), child);
        });
        child.on("error", (error) => {
            const spawnError = error;
            const actionable = spawnError.code === "ENOENT"
                ? new Error(`AtMem engine executable '${command}' was not found. ` +
                    "Install the engine first with `python3 -m pip install atmem`, " +
                    "verify `atmem --version`, or set the plugin `command` option " +
                    "to the executable's absolute path.")
                : error instanceof Error
                    ? error
                    : new Error(String(error));
            this.options.logError?.(`[atmem] spawn failed: ${actionable.message}`);
            this.teardown(actionable, child);
        });
    }
    async handshake() {
        await this.request("initialize", {
            protocolVersion: "2025-06-18",
            capabilities: {},
            clientInfo: {
                name: "openclaw-memory-atmem",
                version: "2.3.5",
            },
        });
        this.notify("notifications/initialized", {});
    }
    request(method, params, timeoutMs) {
        const child = this.child;
        if (!child)
            return Promise.reject(new Error("atmem server not running"));
        const id = this.nextId++;
        const timeout = timeoutMs ?? this.options.defaultTimeoutMs ?? 10_000;
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error(`atmem ${method} timed out after ${timeout}ms`));
            }, timeout);
            this.pending.set(id, { resolve, reject, timer });
            child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
        });
    }
    notify(method, params) {
        this.child?.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n");
    }
    onLine(line) {
        if (!line.trim())
            return;
        let message;
        try {
            message = JSON.parse(line);
        }
        catch {
            this.options.logError?.(`[atmem] unparseable line: ${line.slice(0, 200)}`);
            return;
        }
        if (message.id === undefined)
            return;
        const pending = this.pending.get(message.id);
        if (!pending)
            return;
        this.pending.delete(message.id);
        clearTimeout(pending.timer);
        if (message.error) {
            pending.reject(new Error(`atmem rpc error ${message.error.code}: ${message.error.message}`));
        }
        else {
            pending.resolve(message.result);
        }
    }
    teardown(error, sourceChild) {
        // A closed process can emit its exit event after the next request has
        // already spawned a replacement. Never let that stale event tear down the
        // live child or reject its requests.
        if (sourceChild && this.child !== sourceChild)
            return;
        for (const pending of this.pending.values()) {
            clearTimeout(pending.timer);
            pending.reject(error);
        }
        this.pending.clear();
        this.reader?.close();
        this.reader = null;
        this.child = null;
        this.initialized = null;
    }
}
