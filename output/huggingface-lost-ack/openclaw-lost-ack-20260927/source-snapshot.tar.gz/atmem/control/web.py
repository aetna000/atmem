from __future__ import annotations

from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.metadata import PackageNotFoundError, version
from importlib.resources import files
import json
import os
import secrets
import sys
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from atmem.control import ControlPlaneManager, ControlMode


class ControlDashboardServer(ThreadingHTTPServer):
    def __init__(
        self,
        address: tuple[str, int],
        manager: ControlPlaneManager,
        *,
        html: str,
    ) -> None:
        host, _ = address
        if host not in {"127.0.0.1", "::1", "localhost"}:
            raise ValueError("memory control plane dashboard is loopback-only")
        super().__init__(address, ControlDashboardHandler)
        self.manager = manager
        from atmem.service import AtMemApplication

        self.application = AtMemApplication(manager)
        self.html = html
        self.csrf_token = secrets.token_urlsafe(32)


class ControlDashboardHandler(BaseHTTPRequestHandler):
    server: ControlDashboardServer

    def do_GET(self) -> None:  # noqa: N802
        if not self._valid_host():
            self._json(HTTPStatus.BAD_REQUEST, {"error": "invalid Host header"})
            return
        parsed = urlparse(self.path)
        path = _canonical_api_path(parsed.path)
        if path.startswith("/v1/"):
            self._v1_get(path, parse_qs(parsed.query))
            return
        if path == "/":
            body = self.server.html.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self._security_headers()
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/assets/atmem.jpg":
            body = files("atmem.control").joinpath("assets/atmem.jpg").read_bytes()
            self.send_response(HTTPStatus.OK)
            self._security_headers()
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "public, max-age=86400")
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/session":
            self._json(HTTPStatus.OK, {"csrf_token": self.server.csrf_token})
            return
        if path == "/api/auth/status":
            self._json(HTTPStatus.OK, self.server.application.local_auth_status(self._session_token()))
            return
        if path == "/api/home":
            try:
                self._require_identity_session()
                from atmem.home import HomeService

                service = HomeService()
                status = service.status()
                verification: dict[str, Any] = {"verified": False}
                if status["portable"]:
                    try:
                        verification = service.verify()
                    except (OSError, ValueError, json.JSONDecodeError) as exc:
                        verification = {"verified": False, "error": str(exc)}
                mode = "writable"
                mode_path = service.layout.path("runtime/home-mode.json")
                try:
                    mode = str(json.loads(mode_path.read_text(encoding="utf-8")).get("mode") or mode)
                except (FileNotFoundError, OSError, ValueError, json.JSONDecodeError):
                    pass
                self._json(
                    HTTPStatus.OK,
                    {
                        **status,
                        "verified": bool(verification.get("verified")),
                        "verification_error": verification.get("error"),
                        "mode": mode,
                        "active_writer": service.active_writer(),
                        "migration_command": f"atmem --home {service.layout.root} home migrate DESTINATION",
                    },
                )
            except PermissionError as exc:
                self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
            return
        if path in {"/api/users", "/api/users/audit"}:
            try:
                session = self._require_identity_session(administrator=True)
                self._json(
                    HTTPStatus.OK,
                    {
                        "format": "atmem-local-users-v1",
                        **(
                            {"events": self.server.manager.identity_service().security_audit(session["session_token"])}
                            if path.endswith("/audit")
                            else {"users": self.server.manager.identity_service().list_users(session["session_token"])}
                        ),
                    },
                )
            except PermissionError as exc:
                self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
            return
        if path == "/api/product":
            from atmem.contracts import capabilities
            from atmem.openclaw_install import (
                OPENCLAW_PLUGIN_PACKAGE,
                OPENCLAW_PLUGIN_VERSION,
            )

            try:
                pip_version = version("atmem")
            except PackageNotFoundError:
                pip_version = "development"
            self._json(
                HTTPStatus.OK,
                {
                    "atmem_pip_version": pip_version,
                    "atmem_npm_package": OPENCLAW_PLUGIN_PACKAGE,
                    "atmem_npm_version": OPENCLAW_PLUGIN_VERSION,
                    "x_url": "https://x.com/AtMemX",
                    # The one authoritative capability response. The dashboard
                    # gates its task surfaces on this rather than assuming.
                    "capabilities": capabilities(),
                },
            )
            return
        if path == "/api/companions":
            try:
                self._require_identity_session()
                from atmem.atflows_service import status as atflows_status, validated_dashboard_url

                safe_url = validated_dashboard_url(atflows_status().get("dashboard_url"))
                self._json(HTTPStatus.OK, {"atflows_dashboard_url": safe_url})
            except PermissionError as exc:
                self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
            return
        if path == "/api/status":
            self._json(HTTPStatus.OK, self.server.manager.status())
            return
        if path == "/api/evidence/protection":
            self._json(
                HTTPStatus.OK,
                self.server.manager.evidence_service().protection_status(),
            )
            return
        if path == "/api/semantic/health":
            subject_id = (parse_qs(parsed.query).get("subject") or [None])[0]
            self._json(
                HTTPStatus.OK,
                self.server.manager.semantic_health(subject_id=subject_id),
            )
            return
        if path == "/api/semantic/profiles":
            subject_id = (parse_qs(parsed.query).get("subject") or [None])[0]
            self._json(
                HTTPStatus.OK,
                self.server.manager.semantic_profiles(subject_id=subject_id),
            )
            return
        if path == "/api/companion/status":
            from atmem.control.atbot_service import AtBotServiceManager

            self._json(HTTPStatus.OK, AtBotServiceManager().status())
            return
        if path == "/api/companion/profiles":
            from atmem.control.atbot_service import provider_profiles

            self._json(
                HTTPStatus.OK,
                {
                    "format": "atmem-atbot-provider-profiles-v1",
                    "providers": provider_profiles(),
                    "security": {
                        "stores_api_keys": False,
                        "remote_requires_https": True,
                        "local_requires_loopback": True,
                    },
                },
            )
            return
        if path == "/api/jev/status":
            from atmem.control.jev_service import JevServiceManager

            self._json(HTTPStatus.OK, JevServiceManager().status())
            return
        if path in {"/api/delegated/status", "/api/delegated/doctor", "/api/delegated/self-test"}:
            from atmem.delegated import DelegatedContextService

            service = DelegatedContextService()
            value = (
                service.status()
                if path.endswith("/status")
                else service.doctor()
                if path.endswith("/doctor")
                else service.self_test()
            )
            self._json(HTTPStatus.OK, value)
            return
        if path == "/api/storage/preview":
            params = parse_qs(parsed.query)
            storage_id = (params.get("id") or [""])[0].strip()
            try:
                limit = int((params.get("limit") or ["25"])[0])
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.storage_preview(storage_id, limit=limit),
                )
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        if path == "/api/bridge/status":
            if self.server.manager.state().host != "openclaw":
                self._json(
                    HTTPStatus.OK,
                    {"available": False, "reason": "The generic adapter has no installable bridge."},
                )
                return
            from atmem.openclaw_install import openclaw_bridge_refresh_status

            try:
                self._json(HTTPStatus.OK, openclaw_bridge_refresh_status())
            except ValueError as exc:
                self._json(HTTPStatus.CONFLICT, {"error": str(exc)})
            return
        if path == "/api/blackbox/revision":
            self._json(HTTPStatus.OK, self.server.manager.blackbox_revision())
            return
        if path == "/api/blackbox/runs":
            params = parse_qs(parsed.query)
            try:
                limit = int((params.get("limit") or ["50"])[0])
                offset = int((params.get("offset") or ["0"])[0])
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.blackbox_runs(limit=limit, offset=offset),
                )
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        if path in {
            "/api/blackbox/flight",
            "/api/blackbox/story",
            "/api/blackbox/export",
        }:
            from atmem.control.blackbox import format_flight_report

            params = parse_qs(parsed.query)
            run_id = (params.get("run_id") or [""])[0].strip()
            if not run_id:
                self._json(HTTPStatus.BAD_REQUEST, {"error": "run_id is required"})
                return
            if path == "/api/blackbox/story":
                try:
                    self._json(HTTPStatus.OK, self.server.manager.blackbox_flight_story(run_id))
                except ValueError as exc:
                    self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
                return
            try:
                report = self.server.manager.verify_blackbox_flight(run_id)
            except ValueError as exc:
                self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
                return
            if path == "/api/blackbox/flight":
                self._json(HTTPStatus.OK, report)
                return
            output_format = (params.get("format") or ["json"])[0]
            if output_format == "text":
                content = format_flight_report(report)
                content_type = "text/plain; charset=utf-8"
                suffix = "txt"
            elif output_format == "json":
                content = json.dumps(report, indent=2, sort_keys=True) + "\n"
                content_type = "application/json; charset=utf-8"
                suffix = "json"
            else:
                self._json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "format must be json or text"},
                )
                return
            safe_run = "".join(
                char if char.isalnum() or char in {"-", "_"} else "-"
                for char in run_id
            )[:80]
            self._download(
                content,
                filename=f"atmem-blackbox-{safe_run}.{suffix}",
                content_type=content_type,
            )
            return
        if path == "/api/memory/search":
            params = parse_qs(parsed.query)
            query = (params.get("query") or [""])[0].strip()
            if not query:
                self._json(HTTPStatus.BAD_REQUEST, {"error": "query is required"})
                return
            self._json(
                HTTPStatus.OK,
                self.server.manager.memory_search(
                    query,
                    limit=12,
                    agent_id=(params.get("agent_id") or [None])[0],
                    subject_id=(params.get("subject_id") or [None])[0],
                ),
            )
            return
        if path.startswith("/api/tasks"):
            params = parse_qs(parsed.query)
            value = lambda name: (params.get(name) or [None])[0]
            scope = {
                "subject_id": value("subject"),
                "agent_id": value("agent"),
                "workspace_id": value("workspace"),
            }
            manager = self.server.manager
            if path == "/api/tasks":
                self._json(
                    HTTPStatus.OK,
                    manager.list_tasks(
                        **scope,
                        lifecycles=tuple(params.get("lifecycle") or ()) or None,
                        cursor=value("cursor"),
                        limit=int(value("limit") or 50),
                    ),
                )
                return
            if path == "/api/tasks/mode":
                self._json(HTTPStatus.OK, manager.task_state_mode(**scope))
                return
            if path == "/api/tasks/health":
                self._json(HTTPStatus.OK, manager.task_health(**scope))
                return
            if path == "/api/tasks/detail":
                self._json(
                    HTTPStatus.OK,
                    manager.task_detail(str(value("task_id") or ""), **scope),
                )
                return
            if path == "/api/tasks/timeline":
                self._json(
                    HTTPStatus.OK,
                    manager.task_timeline(str(value("task_id") or ""), **scope),
                )
                return
            if path == "/api/tasks/provenance":
                self._json(
                    HTTPStatus.OK,
                    manager.task_provenance(
                        str(value("task_id") or ""),
                        target_kind=str(value("target_kind") or "task"),
                        target_id=str(value("target_id") or ""),
                        **scope,
                    ),
                )
                return
        if path == "/api/memory/proposals":
            params = parse_qs(parsed.query)
            self._json(
                HTTPStatus.OK,
                self.server.manager.extraction_proposals(
                    (params.get("subject") or [None])[0]
                ),
            )
            return
        if path == "/api/memory/reviews":
            self._json(
                HTTPStatus.OK,
                self.server.manager.memory_reviews(),
            )
            return
        if path == "/api/memory/media-preview":
            if self.server.manager.state().host != "openclaw":
                self._json(
                    HTTPStatus.CONFLICT,
                    {"error": "media preview requires an adapter-owned local media reader"},
                )
                return
            from atmem.control.openclaw_native import resolve_mirror_review_image

            record_id = (parse_qs(parsed.query).get("record_id") or [""])[0].strip()
            try:
                preview = resolve_mirror_review_image(
                    self.server.manager.state(), record_id
                )
            except ValueError as exc:
                self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
                return
            path = preview["path"]
            self.send_response(HTTPStatus.OK)
            self._security_headers()
            self.send_header("Content-Type", str(preview["content_type"]))
            self.send_header("Content-Length", str(preview["bytes"]))
            self.send_header("Content-Disposition", "inline")
            self.send_header(
                "X-AtMem-Media-SHA256", str(preview["media_sha256"])
            )
            self.end_headers()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    self.wfile.write(chunk)
            return
        if path == "/api/memory/trace":
            query = (parse_qs(parsed.query).get("query") or [""])[0].strip()
            if not query:
                self._json(HTTPStatus.BAD_REQUEST, {"error": "query is required"})
                return
            if self.server.manager.state().host == "openclaw":
                from atmem.control.openclaw_native import trace_mirror

                report = trace_mirror(self.server.manager.state(), query, limit=100)
            else:
                report = self.server.manager.memory_search(query, limit=100)
            self._json(HTTPStatus.OK, report)
            return
        if path in {"/api/memory/audit", "/api/memory/audit-export"}:
            params = parse_qs(parsed.query)
            value = lambda name, default="": (params.get(name) or [default])[0].strip()
            filters = {
                "query": value("query"),
                "event_type": value("event_type"),
                "actor": value("actor"),
                "session_id": value("session_id"),
                "record_id": value("record_id"),
                "since": value("since"),
                "until": value("until"),
                "direction": value("direction", "desc"),
            }
            if path == "/api/memory/audit-export":
                output_format = value("format", "json")
                try:
                    content, content_type = self.server.manager.export_memory_audit(
                        output_format=output_format, filters=filters
                    )
                except ValueError as exc:
                    self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                    return
                self._download(
                    content,
                    filename=f"atmem-audit-investigation.{output_format}",
                    content_type=content_type,
                )
                return
            cursor_text = value("cursor")
            try:
                cursor = int(cursor_text) if cursor_text else None
                limit = int(value("limit", "100"))
                report = self.server.manager.memory_audit(
                    **filters,
                    cursor=cursor,
                    limit=limit,
                    include_facets=value("include_facets", "0") == "1",
                )
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            self._json(HTTPStatus.OK, report)
            return
        if path in {
            "/api/memory/record",
            "/api/memory/provenance",
            "/api/memory/record-report",
            "/api/memory/deletion-receipt",
        }:
            params = parse_qs(parsed.query)
            record_id = (params.get("record_id") or [""])[0].strip()
            if not record_id:
                self._json(HTTPStatus.BAD_REQUEST, {"error": "record_id is required"})
                return
            try:
                report = (
                    self.server.manager.memory_provenance(record_id)
                    if path == "/api/memory/provenance"
                    else self.server.manager.memory_record(record_id)
                )
            except ValueError as exc:
                self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
                return
            if path == "/api/memory/record":
                self._json(HTTPStatus.OK, report)
                return
            if path == "/api/memory/provenance":
                self._json(HTTPStatus.OK, report)
                return
            if path == "/api/memory/deletion-receipt":
                receipt = report.get("deletion_receipt")
                if not receipt:
                    self._json(
                        HTTPStatus.NOT_FOUND,
                        {"error": "this record has no deletion receipt"},
                    )
                    return
                self._download(
                    json.dumps(receipt, indent=2, sort_keys=True) + "\n",
                    filename=f"atmem-deletion-{record_id}.json",
                    content_type="application/json; charset=utf-8",
                )
                return
            output_format = (params.get("format") or ["json"])[0]
            if output_format == "text":
                if self.server.manager.state().host == "openclaw":
                    from atmem.control.openclaw_native import format_mirror_record_report

                    content = format_mirror_record_report(report)
                else:
                    record = report.get("record") or {}
                    content = (
                        f"AtMem memory {record_id}\n"
                        f"Status: {report.get('status')}\n"
                        f"Subject: {record.get('subject_id')}\n"
                        f"Content: {record.get('content')}\n"
                        f"SHA-256: {record.get('content_sha256')}\n"
                    )
                self._download(
                    content,
                    filename=f"atmem-investigation-{record_id}.txt",
                    content_type="text/plain; charset=utf-8",
                )
                return
            if output_format != "json":
                self._json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "format must be json or text"},
                )
                return
            self._download(
                json.dumps(report, indent=2, sort_keys=True) + "\n",
                filename=f"atmem-investigation-{record_id}.json",
                content_type="application/json; charset=utf-8",
            )
            return
        self._json(HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/auth/login":
            if not self._same_origin():
                self._json(HTTPStatus.FORBIDDEN, {"error": "origin check failed"})
                return
            try:
                body = self._body()
                result = self.server.manager.identity_service().login(
                    str(body.get("username") or ""),
                    str(body.get("password") or ""),
                    source=str(self.client_address[0]),
                )
                token = result.pop("session_token")
                self._json_with_session(HTTPStatus.OK, result, token)
            except PermissionError as exc:
                self._json(HTTPStatus.UNAUTHORIZED, {"error": str(exc)})
            except ValueError as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        if path in {
            "/api/auth/logout",
            "/api/auth/change-password",
            "/api/users/create",
            "/api/users/update",
            "/api/users/reset-password",
        }:
            self._identity_post(path)
            return
        if path in {"/api/home/verify", "/api/home/adopt"}:
            self._identity_home_post(path)
            return
        if path.startswith("/v1/"):
            if not self._valid_host():
                self._json(HTTPStatus.BAD_REQUEST, {"error": "invalid Host header"})
                return
            self._v1_post(path)
            return
        if not self._same_origin() or not secrets.compare_digest(
            self.headers.get("X-CSRF-Token", ""), self.server.csrf_token
        ):
            self._json(HTTPStatus.FORBIDDEN, {"error": "CSRF check failed"})
            return
        try:
            body = self._body()
            path = _canonical_api_path(urlparse(self.path).path)
            if path == "/api/evidence/capture-mode":
                from atmem.evidence import CaptureMode

                principal = self._dashboard_evidence_principal(body)
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.evidence_service().set_capture_mode(
                        principal, CaptureMode(str(body.get("capture_mode") or ""))
                    ),
                )
                return
            if path == "/api/blackbox/acknowledge":
                run_id = str(body.get("run_id") or "").strip()
                attention_code = str(body.get("attention_code") or "").strip()
                if not run_id or not attention_code:
                    raise ValueError("run_id and attention_code are required")
                if not secrets.compare_digest(
                    str(body.get("confirm_run_id") or ""), run_id
                ):
                    raise ValueError("run confirmation does not match")
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.acknowledge_blackbox_attention(
                        run_id,
                        attention_code,
                        actor="dashboard-reviewer",
                    ),
                )
                return
            if path == "/api/mode":
                mode = ControlMode(str(body["mode"]))
                if mode is not ControlMode.ACTIVE:
                    raise ValueError(
                        "use this endpoint only to activate AtMem; use /api/restore to return safely"
                    )
                expected_host = self.server.manager.state().host
                if not secrets.compare_digest(
                    str(body.get("confirm_host") or ""), expected_host
                ):
                    raise ValueError(
                        f"type the host name `{expected_host}` to confirm"
                    )
                if mode is ControlMode.ACTIVE:
                    self._json(
                        HTTPStatus.OK,
                        self.server.manager.activate(actor="dashboard-reviewer"),
                    )
                    return
            if path == "/api/memory/sync":
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.sync_memory(),
                )
                return
            if path == "/api/semantic/setup":
                provider = str(body.get("provider") or "").strip()
                model = str(body.get("model") or "").strip()
                if not provider or not model:
                    raise ValueError("provider and model are required")
                if not secrets.compare_digest(
                    str(body.get("confirm_model") or ""), model
                ):
                    raise ValueError("model confirmation does not match")
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.setup_semantic_profile(
                        provider=provider,
                        model=model,
                        subject_id=str(body.get("subject_id") or "").strip() or None,
                        allow_download=body.get("allow_download") is True,
                    ),
                )
                return
            if path == "/api/memory/query":
                query = str(body.get("query") or "").strip()
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.memory_query(
                        query,
                        agent_id=str(body.get("agent_id") or "").strip() or None,
                        subject_id=str(body.get("subject_id") or "").strip() or None,
                    ),
                )
                return
            if path == "/api/companion/configure":
                from atmem.control.atbot_service import AtBotServiceManager

                allowed = {"profile", "model", "endpoint", "api_key_env"}
                if set(body) - allowed:
                    raise ValueError("unsupported AtBot configuration fields")
                service = AtBotServiceManager()
                configured = service.configure(
                    profile=str(body.get("profile") or "local-ollama"),
                    model=str(body["model"]).strip() if body.get("model") is not None else None,
                    endpoint=str(body["endpoint"]).strip() if body.get("endpoint") is not None else None,
                    api_key_env=str(body["api_key_env"]).strip() if body.get("api_key_env") is not None else None,
                    force=True,
                )
                self._json(
                    HTTPStatus.OK,
                    {"configured": configured, "status": service.status()},
                )
                return
            if path == "/api/jev/configure":
                from atmem.control.jev_service import JevServiceManager

                allowed = {"enabled", "model", "endpoint", "api_key_env", "timeout_seconds", "fallback"}
                if set(body) - allowed:
                    raise ValueError("unsupported Jev configuration fields")
                result = JevServiceManager().configure(
                    enabled=body.get("enabled") is True,
                    model=str(body.get("model") or "jev-1.13.0"),
                    endpoint=str(body.get("endpoint") or "https://api.typesafe.ai/v1/systemone"),
                    api_key_env=str(body.get("api_key_env") or "JEV_API"),
                    timeout_seconds=float(body.get("timeout_seconds") or 8.0),
                    fallback=str(body.get("fallback") or "native"),
                )
                self._json(HTTPStatus.OK, result)
                return
            if path == "/api/jev/action":
                from atmem.control.jev_service import JevServiceManager

                if set(body) - {"action"}:
                    raise ValueError("Jev action accepts action only")
                action = str(body.get("action") or "")
                if action not in {"enable", "disable"}:
                    raise ValueError("Jev action must be enable or disable")
                self._json(HTTPStatus.OK, JevServiceManager().set_enabled(action == "enable"))
                return
            if path == "/api/companion/action":
                from atmem.control.atbot_service import AtBotServiceManager

                if set(body) - {"action"}:
                    raise ValueError("companion action accepts action only")
                service = AtBotServiceManager()
                action = str(body.get("action") or "")
                if action == "start":
                    result = service.start()
                elif action == "stop":
                    result = service.stop()
                elif action == "restart":
                    service.stop()
                    result = service.start()
                elif action == "skip":
                    service.stop()
                    result = service.skip_setup()
                else:
                    raise ValueError("action must be start, stop, restart, or skip")
                self._json(HTTPStatus.OK, result)
                return
            if path == "/api/evidence/rotate":
                principal = self._dashboard_evidence_principal(body)
                self.server.manager.evidence_service().rotate_key(
                    principal, confirmation=str(body.get("confirmation") or "")
                )
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.evidence_service().protection_status(),
                )
                return
            if path in {"/api/evidence/lock", "/api/evidence/unlock"}:
                service = self.server.manager.evidence_service()
                principal = self._dashboard_evidence_principal(body)
                if path.endswith("/lock"):
                    result = service.lock(principal, confirmation=str(body.get("confirmation") or ""))
                else:
                    result = service.unlock(principal, confirmation=str(body.get("confirmation") or ""))
                self._json(HTTPStatus.OK, result)
                return
            if path == "/api/delegated/action":
                from atmem.delegated import DelegatedConfigStore

                if set(body) - {"action", "registration_id", "confirm_registration_id"}:
                    raise ValueError("unsupported delegated action fields")
                action = str(body.get("action") or "")
                registration_id = str(body.get("registration_id") or "").strip()
                if action not in {"enable", "disable", "remove"}:
                    raise ValueError("action must be enable, disable, or remove")
                if not registration_id:
                    raise ValueError("registration_id is required")
                config = DelegatedConfigStore()
                if action == "remove":
                    if not secrets.compare_digest(
                        str(body.get("confirm_registration_id") or ""), registration_id
                    ):
                        raise ValueError("registration confirmation does not match")
                    current = next(
                        (row for row in config.registrations() if row.registration_id == registration_id),
                        None,
                    )
                    if current is None:
                        raise ValueError("delegated provider registration was not found")
                    if current.enabled:
                        raise ValueError("disable the delegated provider before removing it")
                    result = {"removed": config.remove(registration_id)}
                else:
                    result = config.set_enabled(registration_id, action == "enable")
                self._json(
                    HTTPStatus.OK,
                    {"result": result, "status": config.status()},
                )
                return
            if path == "/api/delegated/register":
                from atmem.delegated import DelegatedConfigStore, DelegatedRegistration

                allowed = {
                    "provider_id", "provider_version", "provider_instance_id",
                    "key_id", "public_key_base64", "endpoint", "workspace_ids",
                    "agent_ids", "user_ids", "timeout_ms", "max_context_bytes",
                    "native_fallback_on_failure", "replace", "request_key_id", "request_secret_file",
                }
                if set(body) - allowed:
                    raise ValueError("unsupported delegated registration fields")
                def identifiers(name: str) -> tuple[str, ...]:
                    value = body.get(name)
                    if not isinstance(value, list):
                        raise ValueError(f"{name} must be a list")
                    return tuple(str(item).strip() for item in value)
                config = DelegatedConfigStore()
                registered = config.register(
                    DelegatedRegistration(
                        provider_id=str(body.get("provider_id") or "").strip(),
                        provider_version=str(body.get("provider_version") or "").strip(),
                        provider_instance_id=str(body.get("provider_instance_id") or "").strip(),
                        key_id=str(body.get("key_id") or "").strip(),
                        public_key_base64=str(body.get("public_key_base64") or "").strip(),
                        endpoint=str(body.get("endpoint") or "").strip(),
                        request_key_id=body.get("request_key_id"),
                        request_secret_file=body.get("request_secret_file"),
                        workspace_ids=identifiers("workspace_ids"),
                        agent_ids=identifiers("agent_ids"),
                        user_ids=identifiers("user_ids"),
                        timeout_ms=int(body.get("timeout_ms") or 3000),
                        max_context_bytes=int(body.get("max_context_bytes") or 262144),
                        enabled=False,
                        native_fallback_on_failure=bool(body.get("native_fallback_on_failure", False)),
                    ),
                    replace=bool(body.get("replace", False)),
                )
                self._json(
                    HTTPStatus.OK,
                    {"registered": registered, "status": config.status()},
                )
                return
            if path == "/api/tasks/mode":
                action = str(body.get("action") or "").strip()
                requested_scope = {
                    "subject_id": str(body.get("subject_id") or "").strip(),
                    "agent_id": str(body.get("agent_id") or "").strip(),
                    "workspace_id": str(body.get("workspace_id") or "").strip(),
                }
                confirmed_scope = body.get("confirm_scope")
                if not all(requested_scope.values()):
                    raise ValueError("complete task-state scope is required")
                if not isinstance(confirmed_scope, dict) or {
                    key: str(confirmed_scope.get(key) or "").strip()
                    for key in requested_scope
                } != requested_scope:
                    raise ValueError("task-state scope confirmation does not match")
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.set_task_state_mode(
                        action,
                        actor=str(body.get("actor") or "dashboard-operator"),
                        **requested_scope,
                    ),
                )
                return
            if path == "/api/tasks/lifecycle":
                task_id = str(body.get("task_id") or "").strip()
                if not task_id or not secrets.compare_digest(
                    str(body.get("confirm_task_id") or ""), task_id
                ):
                    raise ValueError("task confirmation does not match")
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.change_task_lifecycle(
                        task_id,
                        str(body.get("action") or "").strip(),
                        actor=str(body.get("actor") or "dashboard-operator"),
                        reason=str(body.get("reason") or ""),
                        expected_revision=body.get("expected_revision"),
                        subject_id=body.get("subject_id"),
                        agent_id=body.get("agent_id"),
                        workspace_id=body.get("workspace_id"),
                    ),
                )
                return
            if path == "/api/memory/proposal-decision":
                proposal_id = str(body.get("proposal_id") or "").strip()
                if not proposal_id or not secrets.compare_digest(
                    str(body.get("confirm_proposal_id") or ""), proposal_id
                ):
                    raise ValueError("proposal confirmation does not match")
                review_principal = None
                session = self._identity_session()
                if session is not None:
                    session = self._require_identity_session()
                    account = session["account"]
                    account_scope = account["scope"]
                    if account.get("role") == "administrator":
                        review_principal = {
                            "principal_id": account["username"],
                            "subject_id": account_scope["subject_id"],
                            "agent_id": None,
                            "workspace_id": account_scope.get("workspace_id"),
                            "scopes": ("procedure",),
                            "assurance": "local_identity_session",
                        }
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.decide_extraction_proposal(
                        proposal_id,
                        str(body.get("decision") or "").strip(),
                        actor=str(body.get("actor") or "dashboard-reviewer"),
                        reason=str(body.get("reason") or ""),
                        edited_fact=body.get("edited_fact"),
                        review_principal=review_principal,
                    ),
                )
                return
            if path == "/api/memory/review":
                record_id = str(body.get("record_id") or "").strip()
                decision = str(body.get("decision") or "").strip()
                if not secrets.compare_digest(
                    str(body.get("confirm_record_id") or ""), record_id
                ):
                    raise ValueError("record confirmation does not match")
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.review_memory(record_id, decision),
                )
                return
            if path in {
                "/api/memory/correct",
                "/api/memory/exclude",
                "/api/memory/forget",
            }:
                record_id = str(body.get("record_id") or "").strip()
                if not record_id or not secrets.compare_digest(
                    str(body.get("confirm_record_id") or ""), record_id
                ):
                    raise ValueError("record confirmation does not match")
                if path == "/api/memory/correct":
                    result = self.server.manager.correct_memory(
                        record_id,
                        str(body.get("corrected_text") or ""),
                        str(body.get("reason") or ""),
                    )
                elif path == "/api/memory/exclude":
                    if not isinstance(body.get("excluded"), bool):
                        raise ValueError("excluded must be true or false")
                    result = self.server.manager.exclude_memory(
                        record_id,
                        bool(body["excluded"]),
                        str(body.get("reason") or ""),
                    )
                else:
                    result = self.server.manager.forget_memory(record_id)
                self._json(HTTPStatus.OK, result)
                return
            if path == "/api/restore":
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.deactivate(actor="dashboard-reviewer"),
                )
                return
            if path == "/api/restore-drill":
                if self.server.manager.state().host != "openclaw":
                    raise ValueError(
                        "restore drill requires an adapter with preserved native host state"
                    )
                from atmem.control.openclaw_native import restore_drill

                self._json(
                    HTTPStatus.OK,
                    restore_drill(self.server.manager.state()),
                )
                return
            if path == "/api/verify":
                self._json(
                    HTTPStatus.OK,
                    self.server.manager.verify(probe=bool(body.get("probe", False))),
                )
                return
            if path == "/api/bridge/refresh-test":
                expected_host = self.server.manager.state().host
                if expected_host != "openclaw":
                    raise ValueError(
                        "bridge refresh is available only for the OpenClaw adapter"
                    )
                if not secrets.compare_digest(
                    str(body.get("confirm_host") or ""), expected_host
                ):
                    raise ValueError(
                        f"type the host name `{expected_host}` to confirm"
                    )
                from atmem.openclaw_install import refresh_openclaw_bridge_and_test

                self._json(
                    HTTPStatus.OK,
                    refresh_openclaw_bridge_and_test(
                        state_path=self.server.manager.state_path
                    ),
                )
                return
            self._json(HTTPStatus.NOT_FOUND, {"error": "not found"})
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            self._json(HTTPStatus.CONFLICT, {"error": str(exc)})

    def _v1_principal(self):
        from atmem.service import APIError, APIPrincipal

        identity_session = self._identity_session()
        if identity_session is not None:
            account = identity_session["account"]
            if account.get("password_change_required"):
                raise APIError("password_change_required", "change the temporary password before opening evidence", status=403)
            scope = account["scope"]
            return APIPrincipal(
                principal_id=account["username"],
                role="admin" if account["role"] == "administrator" else "agent",
                subject_id=scope["subject_id"],
                workspace_id=scope.get("workspace_id"),
                tenant_id=scope["tenant_id"],
                evidence_role=account["role"],
                credential_kind="local_session",
            )
        authorization = self.headers.get("Authorization", "")
        prefix = "Bearer "
        if not authorization.startswith(prefix):
            raise APIError("unauthenticated", "a valid local bearer credential is required", status=401)
        token = authorization[len(prefix) :]
        evidence_principal = self.server.manager.evidence_service().authenticate(token)
        if evidence_principal is not None:
            return APIPrincipal(
                principal_id=evidence_principal.principal_id,
                role="agent",
                subject_id=evidence_principal.scope.subject_id,
                workspace_id=evidence_principal.scope.workspace_id,
                tenant_id=evidence_principal.scope.tenant_id,
                evidence_role=evidence_principal.role.value,
                credential_kind="legacy_evidence_bearer",
                evidence_run_id=evidence_principal.scope.run_id,
            )
        if not secrets.compare_digest(token, self.server.csrf_token):
            raise APIError("unauthenticated", "a valid local bearer credential is required", status=401)
        role = self.headers.get("X-AtMem-Role", "agent").strip().lower()
        if role not in {"agent", "admin"}:
            raise APIError("invalid_principal", "role must be agent or admin", status=400)
        subject_id = self.headers.get("X-AtMem-Subject", "").strip() or self.server.manager.state().subject_id
        return APIPrincipal(
            principal_id=self.headers.get("X-AtMem-Principal", "local-client").strip() or "local-client",
            role=role,
            subject_id=subject_id,
            agent_id=self.headers.get("X-AtMem-Agent", "").strip() or None,
            workspace_id=self.headers.get("X-AtMem-Workspace", "").strip() or None,
        )

    def _v1_get(self, path: str, query: dict[str, list[str]]) -> None:
        from atmem.service import APIError

        try:
            principal = self._v1_principal()
            if path == "/v1/health":
                value = self.server.application.health(principal)
            elif path == "/v1/continuity":
                service, actor = self._continuity(principal)
                value = {"workflows": service.list(actor)}
            elif path.startswith("/v1/continuity/"):
                service, actor = self._continuity(principal)
                value = service.get(actor, path.rsplit("/", 1)[-1])
            elif path == "/v1/capabilities":
                value = self.server.application.capability_manifest(principal)
            elif path == "/v1/memories":
                value = self.server.application.list_memories(
                    principal,
                    query=(query.get("query") or [""])[0],
                    limit=int((query.get("limit") or ["50"])[0]),
                    cursor=(query.get("cursor") or [None])[0],
                ).to_dict()
            elif path == "/v1/reviews":
                value = self.server.application.reviews(principal)
            elif path == "/v1/audit":
                value = self.server.application.audit(
                    principal,
                    limit=int((query.get("limit") or ["100"])[0]),
                    cursor=int((query.get("cursor") or ["0"])[0]) or None,
                )
            elif path == "/v1/executions":
                value = self.server.application.executions(
                    principal, limit=int((query.get("limit") or ["50"])[0])
                )
            elif path.startswith("/v1/executions/"):
                value = self.server.application.execution(
                    principal, unquote(path.rsplit("/", 1)[-1])
                )
            elif path == "/v1/evidence/status":
                value = self.server.application.evidence_status(principal)
            elif path.startswith("/v1/evidence/runs/"):
                value = self.server.application.evidence_run(
                    principal, unquote(path.rsplit("/", 1)[-1])
                )
            elif path == "/v1/evidence/search":
                value = self.server.application.evidence_search(
                    principal, (query.get("query") or [""])[0]
                )
            elif path == "/v1/configuration":
                value = self.server.application.configuration(principal)
            elif path.startswith("/v1/features/"):
                value = self.server.application.feature_status(principal, path.rsplit("/", 1)[-1])
            elif path == "/v1/lifecycle":
                value = self.server.application.lifecycle(principal, (query.get("record_id") or [""])[0], evaluated_at=(query.get("evaluated_at") or [None])[0])
            else:
                raise APIError("not_found", "resource not found", status=404)
            self._json(HTTPStatus.OK, value)
        except APIError as exc:
            self._json(exc.status, exc.to_dict())
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, APIError("forbidden", str(exc), status=403).to_dict())
        except (TypeError, ValueError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, APIError("invalid_request", str(exc), status=400).to_dict())

        except (OSError, RuntimeError) as exc:
            self._json(HTTPStatus.SERVICE_UNAVAILABLE, APIError("unavailable", str(exc), status=503).to_dict())

    def _v1_post(self, path: str) -> None:
        from atmem.service import APIError

        try:
            identity_session = self._identity_session()
            if identity_session is not None and not secrets.compare_digest(
                self.headers.get("X-CSRF-Token", ""),
                str(identity_session.get("csrf_token") or ""),
            ):
                raise APIError("csrf_failed", "CSRF check failed", status=403)
            principal = self._v1_principal()
            body = self._body()
            if path == "/v1/memories":
                value = self.server.application.create_memory(
                    principal,
                    str(body.get("message") or ""),
                    idempotency_key=str(body.get("idempotency_key") or ""),
                    session_id=body.get("session_id"),
                )
            elif path == "/v1/continuity":
                service, actor = self._continuity(principal)
                if set(body) - {"workflow_key", "operations", "activate"}:
                    raise ValueError("unexpected workflow field; scope comes from the credential")
                value = service.create(actor, body["workflow_key"], body["operations"], activate=body.get("activate", False))
            elif path.startswith("/v1/continuity/"):
                service, actor = self._continuity(principal)
                parts = path.split("/")
                if len(parts) != 5:
                    raise ValueError("invalid continuity action")
                workflow_id, action = parts[3:]
                if action == "configure":
                    value = service.configure(actor, workflow_id, enabled=body["enabled"])
                elif action == "begin":
                    value = service.begin(actor, workflow_id, body["name"], body["run_id"], body["attempt_id"])
                elif action == "outcome":
                    value = service.outcome(actor, workflow_id, body["name"], body["lease_token"], body["receipt"], run_id=body["run_id"], attempt_id=body["attempt_id"])
                elif action == "renew":
                    value = service.renew(actor, workflow_id, body["name"], body["lease_token"], run_id=body["run_id"], attempt_id=body["attempt_id"])
                elif action == "abandon":
                    value = service.abandon(actor, workflow_id, body["name"], body["reason"])
                else:
                    raise ValueError("unknown continuity action")
            elif path == "/v1/query":
                value = self.server.application.query(principal, str(body.get("query") or ""))
            elif path == "/v1/lifecycle":
                value = self.server.application.transition_lifecycle(principal, body)
            elif path == "/v1/interchange/plan":
                value = self.server.application.interchange_plan(principal, body)
            elif path == "/v1/media/revoke":
                value = self.server.application.revoke_media(principal, str(body.get("artifact_id") or ""))
            elif path == "/v1/evidence/reconstruct":
                value = self.server.application.evidence_reconstruct(
                    principal, str(body.get("run_id") or "")
                )
            elif path == "/v1/evidence/replay-manifest":
                value = self.server.application.evidence_replay_manifest(
                    principal, str(body.get("run_id") or "")
                )
            elif path == "/v1/evidence/delete":
                value = self.server.application.evidence_delete(
                    principal,
                    str(body.get("run_id") or ""),
                    confirmation=str(body.get("confirmation") or ""),
                )
            elif path == "/v1/evidence/settings/rotate":
                value = self.server.application.evidence_rotate(
                    principal, confirmation=str(body.get("confirmation") or "")
                )
            elif path == "/v1/evidence/settings/lock":
                value = self.server.application.evidence_lock(
                    principal, confirmation=str(body.get("confirmation") or "")
                )
            elif path == "/v1/evidence/settings/unlock":
                value = self.server.application.evidence_unlock(
                    principal, confirmation=str(body.get("confirmation") or "")
                )
            elif path == "/v1/evidence/grants":
                value = self.server.application.evidence_grant(principal, body)
            elif path == "/v1/evidence/revoke":
                value = self.server.application.evidence_revoke(
                    principal, str(body.get("principal_id") or "")
                )
            elif path == "/v1/evidence/export/plaintext":
                value = self.server.application.evidence_plaintext_export(
                    principal,
                    str(body.get("run_id") or ""),
                    confirmation=str(body.get("confirmation") or ""),
                )
            elif path == "/v1/evidence/settings/capture-mode":
                value = self.server.application.evidence_capture_mode(
                    principal, str(body.get("capture_mode") or "")
                )
            else:
                raise APIError("not_found", "resource not found", status=404)
            self._json(HTTPStatus.OK, value)
        except APIError as exc:
            self._json(exc.status, exc.to_dict())
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, APIError("forbidden", str(exc), status=403).to_dict())
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            self._json(HTTPStatus.CONFLICT, APIError("conflict", str(exc), status=409).to_dict())

    def _continuity(self, principal):
        from atmem.continuity import ContinuityService
        return (ContinuityService(self.server.manager.evidence_service()),
                self.server.application._evidence_principal(principal))

    def log_message(self, format: str, *args: Any) -> None:
        del format, args

    def _session_token(self) -> str:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except Exception:
            return ""
        morsel = cookie.get("atmem_session")
        return morsel.value if morsel is not None else ""

    def _identity_session(self) -> dict[str, Any] | None:
        token = self._session_token()
        if not token:
            return None
        session = self.server.manager.identity_service().authenticate_session(token)
        if session is not None:
            session["session_token"] = token
        return session

    def _require_identity_session(self, *, administrator: bool = False) -> dict[str, Any]:
        session = self._identity_session()
        if session is None:
            raise PermissionError("sign-in required")
        if session["account"].get("password_change_required"):
            raise PermissionError("password change required")
        if administrator and session["account"].get("role") != "administrator":
            raise PermissionError("Administrator access required")
        return session

    def _dashboard_evidence_principal(self, body: dict[str, Any]):
        session = self._identity_session()
        if session is not None:
            if session["account"].get("password_change_required"):
                raise PermissionError("password change required")
            return self.server.manager.identity_service().evidence_principal(session)
        principal = self.server.manager.evidence_service().authenticate(
            str(body.get("token") or "")
        )
        if principal is None:
            raise PermissionError("sign in with an Evidence Collector or Administrator account")
        return principal

    def _identity_post(self, path: str) -> None:
        if not self._same_origin():
            self._json(HTTPStatus.FORBIDDEN, {"error": "origin check failed"})
            return
        service = self.server.manager.identity_service()
        session = self._identity_session()
        if session is None:
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "sign-in required"})
            return
        if not secrets.compare_digest(
            self.headers.get("X-CSRF-Token", ""), str(session.get("csrf_token") or "")
        ):
            self._json(HTTPStatus.FORBIDDEN, {"error": "CSRF check failed"})
            return
        try:
            body = self._body()
            token = session["session_token"]
            if path == "/api/auth/logout":
                service.logout(token)
                self._json_clear_session(HTTPStatus.OK, {"logged_out": True})
                return
            if path == "/api/auth/change-password":
                result = service.change_password(
                    token,
                    str(body.get("current_password") or ""),
                    str(body.get("new_password") or ""),
                )
                new_token = result.pop("session_token")
                self._json_with_session(HTTPStatus.OK, result, new_token)
                return
            self._require_identity_session(administrator=True)
            if path == "/api/users/create":
                value = service.create_user(
                    token,
                    str(body.get("username") or ""),
                    str(body.get("role") or ""),
                    display_name=str(body.get("display_name") or ""),
                )
            elif path == "/api/users/update":
                value = service.update_user(
                    token,
                    str(body.get("username") or ""),
                    enabled=body.get("enabled"),
                    role=body.get("role"),
                )
            else:
                value = service.reset_password(token, str(body.get("username") or ""))
            self._json(HTTPStatus.OK, value)
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except (TypeError, ValueError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})

    def _identity_home_post(self, path: str) -> None:
        if not self._same_origin():
            self._json(HTTPStatus.FORBIDDEN, {"error": "origin check failed"})
            return
        session = self._identity_session()
        if session is None:
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "sign-in required"})
            return
        if not secrets.compare_digest(
            self.headers.get("X-CSRF-Token", ""), str(session.get("csrf_token") or "")
        ):
            self._json(HTTPStatus.FORBIDDEN, {"error": "CSRF check failed"})
            return
        try:
            from atmem.home import HomeService

            service = HomeService()
            if path == "/api/home/verify":
                self._json(HTTPStatus.OK, service.verify())
                return
            self._require_identity_session(administrator=True)
            body = self._body()
            expected = str(service.layout.root)
            if not secrets.compare_digest(str(body.get("confirm_home") or ""), expected):
                raise ValueError("confirm the displayed AtMem Home path before adoption")
            receipt = service.adopt(
                administrator_confirmed=True,
                allowed_writer_pid=os.getpid(),
            )
            rotation = self.server.manager.identity_service().revoke_all_sessions(
                session["session_token"], reason="portable home adopted"
            )
            self._json_clear_session(HTTPStatus.OK, {**receipt, **rotation})
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except (OSError, TypeError, ValueError) as exc:
            self._json(HTTPStatus.CONFLICT, {"error": str(exc)})

    def _json_with_session(self, status: HTTPStatus, value: Any, token: str) -> None:
        body = json.dumps(value, indent=2, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        cookie = f"atmem_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200"
        if self.headers.get("X-Forwarded-Proto", "").lower() == "https":
            cookie += "; Secure"
        self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json_clear_session(self, status: HTTPStatus, value: Any) -> None:
        body = json.dumps(value, indent=2, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Set-Cookie", "atmem_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _same_origin(self) -> bool:
        host = self.headers.get("Host", "")
        allowed = {
            f"127.0.0.1:{self.server.server_port}",
            f"localhost:{self.server.server_port}",
        }
        if host not in allowed:
            return False
        origin = self.headers.get("Origin")
        return origin is None or origin in {f"http://{item}" for item in allowed}

    def _valid_host(self) -> bool:
        return self.headers.get("Host", "") in {
            f"127.0.0.1:{self.server.server_port}",
            f"localhost:{self.server.server_port}",
        }

    def _body(self) -> dict[str, Any]:
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        if size < 0 or size > 1_000_000:
            raise ValueError("request body is too large")
        value = json.loads(self.rfile.read(size) or b"{}")
        if not isinstance(value, dict):
            raise ValueError("request body must be a JSON object")
        return value

    def _json(self, status: HTTPStatus, value: Any) -> None:
        body = json.dumps(value, indent=2, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self._security_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _download(self, value: str, *, filename: str, content_type: str) -> None:
        body = value.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self._security_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _security_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; media-src 'self' data:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; connect-src 'self'; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")


def _canonical_api_path(path: str) -> str:
    """Keep legacy mirror URLs working while exposing host-neutral memory URLs."""

    if path.startswith("/api/mirror/"):
        return "/api/memory/" + path.removeprefix("/api/mirror/")
    return path


def dashboard_html() -> str:
    try:
        from atmem.control.ui import APP_HTML

        return APP_HTML
    except Exception as exc:  # dashboard must degrade, never crash
        print(
            f"atmem: dashboard assets unavailable ({exc}); serving JSON fallback",
            file=sys.stderr,
        )
        return _FALLBACK_HTML


_FALLBACK_HTML = """<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>AtMem memory control plane</title>
<style>
body{font:16px system-ui;max-width:760px;margin:4rem auto;padding:0 1rem;color:#1a2b2f}
pre{background:#f1f4f3;padding:1rem;overflow:auto}button{padding:.6rem 1rem}
</style>
<h1>AtMem memory control plane</h1>
<p id="mode" role="status">Loading verified local state…</p>
<pre id="status"></pre>
<script>
let csrf="";
async function load(){
 const s=await fetch("/api/session").then(r=>r.json());csrf=s.csrf_token;
 const v=await fetch("/api/status").then(r=>r.json());
 document.querySelector("#mode").textContent=`Mode: ${v.mode} — context changes: ${v.changes_model_context}`;
 document.querySelector("#status").textContent=JSON.stringify(v,null,2);
} load();
</script></html>"""
