from __future__ import annotations

import re


# Hosts AtMem has actually been exercised against. Activation fails closed on
# anything else rather than taking over native memory on an unverified host.
#
# This list must match the recorded bridge fixtures in
# `integrations/openclaw/test/fixtures/hook-context/`, which pin the declared
# hook-context surface per version. Two lists describing "which OpenClaw do we
# support" that nobody checks against each other is how the 2.2.6b6 manifest
# drift happened; `test_openclaw_compat.py` ties them together.
#
# 2026.9.2 verification: the declared hook-context surface (no task identity;
# sessionId, sessionKey and senderIsOwner present), the full bridge npm suite,
# and every CLI surface the takeover path calls -- config get, plugins inspect,
# gateway status/restart/stop, hooks disable -- were checked against a live
# 2026.9.2 install.
TESTED_OPENCLAW_VERSIONS = (
    "2026.7.1-2",
    "2026.8.1",
    "2026.9.2",
    "2026.9.3",
    "2026.9.4",
    "2026.9.5",
    "2026.9.6",
)

_VERSION_RE = re.compile(r"(?<!\d)(\d{4})\.(\d+)\.(\d+)(?:-(\d+))?(?!\d)")


def parse_openclaw_version(value: str) -> tuple[int, int, int, int | None]:
    match = _VERSION_RE.search(value.strip())
    if match is None:
        raise ValueError(f"could not parse OpenClaw version: {value!r}")
    year, minor, patch, suffix = match.groups()
    return int(year), int(minor), int(patch), int(suffix) if suffix else None


def normalize_openclaw_version(value: str) -> str:
    year, minor, patch, suffix = parse_openclaw_version(value)
    base = f"{year}.{minor}.{patch}"
    return f"{base}-{suffix}" if suffix is not None else base


def evaluate_host_version(value: str) -> str:
    parsed = parse_openclaw_version(value)
    tested = [parse_openclaw_version(item) for item in TESTED_OPENCLAW_VERSIONS]
    if parsed in tested:
        return "tested"
    if any(parsed[:2] == candidate[:2] for candidate in tested):
        return "untested_patch"
    return "untested"
