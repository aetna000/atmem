"""The sole supported plaintext boundary for encrypted evidence."""

from __future__ import annotations

from hashlib import sha256
import base64
import json
from pathlib import Path
from typing import Any
from collections.abc import Iterator
import os
from functools import wraps
from atmem.locking import ProcessFileLock


def _key_transition(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self.key_transition_lock():
            # Re-read under the shared lock, not from a pre-lock instance.
            try:
                self._key = load_existing_key(self.key_path)
            except FileNotFoundError:
                self._key = None
            return method(self, *args, **kwargs)
    return guarded

from atmem.core.canonical import canonical_json
from atmem.evidence.accounts import EvidenceAccountStore
from atmem.evidence.crypto import encrypted_export, load_existing_key, load_or_create_key, open_json, seal_json, write_key
from atmem.evidence.models import (
    CaptureMode,
    EvidenceOperation,
    EvidencePrincipal,
    EvidenceRole,
    EvidenceScope,
)
from atmem.evidence.store import EncryptedEvidenceStore
from atmem.home.artifacts import ArtifactVault
from atmem.home.layout import resolve_home


class EvidenceService:
    def __init__(
        self,
        root: str | Path,
        *,
        vault_id: str,
        home_root: str | Path | None = None,
    ) -> None:
        self.root = Path(root).expanduser().resolve(strict=False)
        self.vault_id = str(vault_id)
        self.key_path = self.root.parent / ".evidence-keys" / f"{self.vault_id}.key"
        self.vault_path = self.root / "protected-evidence.db"
        self.identity_key_path = self.root.parent / ".evidence-identity-keys" / f"{self.vault_id}.key"
        self._identity_key = load_or_create_key(self.identity_key_path)
        self.locked_key_path = self.key_path.with_suffix(".locked")
        self._key: bytes | None
        try:
            self._key = (
                load_existing_key(self.key_path)
                if self.vault_path.exists()
                else load_or_create_key(self.key_path)
            )
        except FileNotFoundError:
            self._key = None
        if home_root is not None or os.environ.get("ATMEM_HOME"):
            self.home_root = resolve_home(home_root)
        elif self.root.parent.name == "migrations":
            self.home_root = self.root.parent.parent
        else:
            # Explicit test/embedded roots remain self-contained instead of
            # unexpectedly writing into the user's default home.
            self.home_root = self.root.parent
        self.artifact_root = self.home_root / "artifacts" / "sha256"
        self.artifact_key_path = self.home_root / "identity" / "artifact.key"
        self._artifact_key = (
            load_existing_key(self.artifact_key_path)
            if any(self.artifact_root.glob("*/*.blob"))
            else load_or_create_key(self.artifact_key_path)
        )
        self.accounts_path = self.root.parent / ".evidence-accounts" / f"{self.vault_id}.json"
        self.rotation_path = self.key_path.with_suffix(".rotation")
        if self._key is not None and self.rotation_path.exists():
            self._resume_rotation()
        self.accounts = EvidenceAccountStore(self.accounts_path, self._identity_key)
        if self.accounts_path.exists():
            try:
                self.accounts._load()
            except Exception:
                if self._key is None:
                    raise RuntimeError("evidence identity records require migration while the vault key is available")
                legacy_accounts = EvidenceAccountStore(self.accounts_path, self._key)
                value = legacy_accounts._load()
                self.accounts._write(value)

    def _key_opens_vault(self, key: bytes) -> bool:
        try:
            with EncryptedEvidenceStore(self.vault_path, key) as store:
                next(iter(store.documents()), None)
            return True
        except Exception:
            return False

    def _resume_rotation(self) -> None:
        assert self._key is not None
        wrapper = json.loads(self.rotation_path.read_text(encoding="utf-8"))
        try:
            value = open_json(
                self._key,
                f"rotation:{self.vault_id}",
                base64.b64decode(wrapper["nonce"], validate=True),
                base64.b64decode(wrapper["ciphertext"], validate=True),
            )
        except Exception:
            if self._key_opens_vault(self._key):
                self.rotation_path.unlink()
                return
            self._key = None
            return
        candidate = base64.b64decode(value["new_key"], validate=True)
        if self._key_opens_vault(candidate):
            from atmem.control.store import reencrypt_control_container

            control_path = self.root / "evidence.db"
            if control_path.exists():
                reencrypt_control_container(control_path, self._key, candidate)
            write_key(self.key_path, candidate, replace=True)
            self._key = candidate
        self.rotation_path.unlink()

    def _write_rotation_journal(self, new_key: bytes) -> None:
        assert self._key is not None
        nonce, ciphertext = seal_json(
            self._key,
            f"rotation:{self.vault_id}",
            {"format": "atmem-evidence-key-rotation-v1", "new_key": base64.b64encode(new_key).decode()},
        )
        descriptor = os.open(self.rotation_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(
                {"format": "atmem-encrypted-key-rotation-journal-v1", "nonce": base64.b64encode(nonce).decode(), "ciphertext": base64.b64encode(ciphertext).decode()},
                handle,
                separators=(",", ":"),
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

    def _store(self) -> EncryptedEvidenceStore:
        if self._key is None:
            raise PermissionError(
                "encrypted evidence is locked because its external key is unavailable"
            )
        return EncryptedEvidenceStore(self.vault_path, self._key)

    def key_transition_lock(self):
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        return ProcessFileLock(self.root / ".key-transition.lock", blocking=True)

    def storage_key(self) -> bytes:
        if self._key is None:
            raise PermissionError("encrypted evidence is locked")
        return self._key

    def protection_status(self) -> dict[str, Any]:
        from atmem.control.store import ENCRYPTED_CONTROL_MAGIC

        plaintext_sources: list[str] = []
        for candidate in self.root.glob("*.db"):
            if candidate == self.vault_path:
                continue
            try:
                if not candidate.read_bytes()[: len(ENCRYPTED_CONTROL_MAGIC)] == ENCRYPTED_CONTROL_MAGIC:
                    plaintext_sources.append(candidate.name)
            except OSError:
                plaintext_sources.append(candidate.name)
        if self._key is None:
            return {
                "format": "atmem-evidence-protection-status-v1",
                "encrypted": True,
                "locked": True,
                "key_source": "application-locked" if self.locked_key_path.exists() else "external-key-unavailable",
                "capture_mode": "unavailable",
                "data_enabled": False,
                "recorder_enabled": False,
                "plaintext_export_role": EvidenceRole.EVIDENCE_COLLECTOR.value,
                "stored_objects": None,
                "at_rest_state": "encrypted_locked",
                "plaintext_source_exists": bool(plaintext_sources),
                "plaintext_sources": plaintext_sources,
                "recovery_action": "Authenticate as Evidence Collector and unlock AtMem." if self.locked_key_path.exists() else "Restore the configured evidence key, then restart AtMem.",
            }
        with self._store() as store:
            mode = store.capture_mode()
            return {
                "format": "atmem-evidence-protection-status-v1",
                "encrypted": True,
                "locked": False,
                "key_source": "external-mode-0600-development-key",
                "capture_mode": mode.value,
                "data_enabled": mode is CaptureMode.FULL,
                "recorder_enabled": mode is not CaptureMode.OFF,
                "plaintext_export_role": EvidenceRole.EVIDENCE_COLLECTOR.value,
                "stored_objects": store.count(),
                "at_rest_state": "plaintext_source_exists" if plaintext_sources else "encrypted",
                "plaintext_source_exists": bool(plaintext_sources),
                "plaintext_sources": plaintext_sources,
            }

    def set_capture_mode(self, principal: EvidencePrincipal, mode: CaptureMode) -> dict[str, Any]:
        target = EvidenceScope(principal.scope.tenant_id, principal.scope.subject_id)
        principal.authorize(EvidenceOperation.RETENTION, target)
        with self._store() as store, store.atomic():
            if mode is not CaptureMode.FULL:
                workflows = {}
                for doc in store.documents():
                    if doc.get("record_type") == "continuity":
                        workflows[doc["workflow"]["workflow_id"]] = doc["workflow"]
                    elif doc.get("record_type") == "continuity_tombstone":
                        workflows.pop(doc["workflow_id"], None)
                if any(w["enabled"] or any(op["status"] == "uncertain" for op in w["operations"]) for w in workflows.values()):
                    raise ValueError("disable continuity workflows and resolve or abandon uncertain work before reducing capture")
            store.set_capture_mode(mode, actor=principal.principal_id)
            store.access_event(self._audit(principal, "capture_mode", target, True, mode=mode.value))
        return self.protection_status()

    def capture(self, envelope: dict[str, Any]) -> dict[str, Any]:
        scope = self._scope_from_envelope(envelope)
        with self._store() as store:
            mode = store.capture_mode()
            stored_envelope = (
                self._externalize_artifacts(envelope)
                if mode is CaptureMode.FULL
                else envelope
            )
            result = store.capture(stored_envelope)
        return {
            "format": "atmem-protected-capture-receipt-v1",
            "captured": result is not None,
            "capture_mode": mode.value,
            "reconstructable": mode is CaptureMode.FULL,
            "object_id": result.get("object_id") if result else None,
            "scope": scope.to_dict(),
        }

    def events(self, principal: EvidencePrincipal, run_id: str) -> list[dict[str, Any]]:
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            run_id,
        )
        try:
            principal.authorize(EvidenceOperation.VIEW, target)
        except PermissionError:
            self._record_access(principal, "view", target, False)
            raise
        with self._store() as store:
            values = []
            for item in store.documents():
                if item.get("record_type") != "evidence":
                    continue
                envelope = dict(item.get("envelope") or {})
                item_scope = self._scope_from_envelope(envelope)
                if (
                    principal.scope.permits(item_scope)
                    and str(envelope.get("run_id") or "") == run_id
                ):
                    values.append(self._materialize_artifacts(item))
            store.access_event(self._audit(principal, "view", target, True, count=len(values)))
        return values

    def has_run_session(
        self, principal: EvidencePrincipal, run_id: str, session_id: str
    ) -> bool:
        """Check one authorized run/session link without loading artifact bytes."""
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            run_id,
        )
        try:
            principal.authorize(EvidenceOperation.VIEW, target)
        except PermissionError:
            self._record_access(principal, "view", target, False)
            raise
        with self._store() as store:
            matched = any(
                item.get("record_type") == "evidence"
                and str((item.get("envelope") or {}).get("run_id") or "") == run_id
                and str((item.get("envelope") or {}).get("session_id") or "") == session_id
                and principal.scope.permits(
                    self._scope_from_envelope(item.get("envelope") or {})
                )
                for item in store.documents()
            )
            store.access_event(
                self._audit(principal, "view", target, True, metadata_only=True)
            )
        return matched

    def reconstruct(self, principal: EvidencePrincipal, run_id: str) -> dict[str, Any]:
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            run_id,
        )
        try:
            principal.authorize(EvidenceOperation.RECONSTRUCT, target)
        except PermissionError:
            self._record_access(principal, "reconstruct", target, False)
            raise
        events = self.events(principal, run_id)
        reconstructable = bool(events) and all(item.get("reconstructable") is True for item in events)
        self._record_access(
            principal,
            "reconstruct",
            target,
            True,
            event_count=len(events),
            reconstructable=reconstructable,
        )
        return {
            "format": "atmem-evidence-reconstruction-v1",
            "run_id": run_id,
            "reconstructable": reconstructable,
            "events": events,
        }

    def search(self, principal: EvidencePrincipal, query: str) -> list[dict[str, Any]]:
        clean = str(query or "").strip()
        if not clean:
            raise ValueError("evidence search query is required")
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            principal.scope.run_id,
        )
        try:
            principal.authorize(EvidenceOperation.SEARCH, target)
        except PermissionError:
            self._record_access(principal, "search", target, False)
            raise
        needle = clean.casefold()
        matches: list[dict[str, Any]] = []
        with self._store() as store:
            for item in store.documents():
                if item.get("record_type") != "evidence":
                    continue
                envelope = dict(item.get("envelope") or {})
                scope = self._scope_from_envelope(envelope)
                if principal.scope.permits(scope) and needle in canonical_json(envelope).casefold():
                    matches.append(item)
            store.access_event(self._audit(principal, "search", target, True, count=len(matches)))
        return matches

    def replay_manifest(self, principal: EvidencePrincipal, run_id: str) -> dict[str, Any]:
        target = EvidenceScope(
            principal.scope.tenant_id, principal.scope.subject_id,
            principal.scope.workspace_id, run_id,
        )
        try:
            principal.authorize(EvidenceOperation.REPLAY_MANIFEST, target)
        except PermissionError:
            self._record_access(principal, "replay_manifest", target, False)
            raise
        events = self.events(principal, run_id)
        canonical = canonical_json(events)
        manifest = {
            "format": "atmem-inert-replay-manifest-v1",
            "run_id": run_id,
            "event_count": len(events),
            "events_sha256": sha256(canonical.encode()).hexdigest(),
            "executable": False,
            "warning": "This manifest reconstructs captured inputs; it does not authorize execution.",
        }
        self._record_access(principal, "replay_manifest", target, True)
        return manifest

    def grant(
        self, principal: EvidencePrincipal, *, principal_id: str,
        role: EvidenceRole, scope: EvidenceScope,
    ) -> dict[str, str]:
        principal.authorize(EvidenceOperation.GRANT, scope)
        if role is EvidenceRole.CONTINUITY_HOST and not scope.run_id:
            raise ValueError("continuity host grants require an explicit workflow run_id")
        if role is EvidenceRole.CONTINUITY_COORDINATOR and (not scope.workspace_id or scope.run_id):
            raise ValueError("continuity coordinator requires an explicit workspace and no workflow binding")
        if not principal.scope.permits(scope):
            raise PermissionError("cannot grant evidence access outside the collector scope")
        credential = self.accounts.grant(principal_id, role, scope)
        self._record_access(principal, "grant", scope, True, grantee=principal_id, role=role.value)
        return credential

    def revoke(self, principal: EvidencePrincipal, *, principal_id: str) -> bool:
        target = principal.scope
        principal.authorize(EvidenceOperation.GRANT, target)
        changed = self.accounts.revoke(principal_id)
        self._record_access(principal, "revoke", target, True, grantee=principal_id, changed=changed)
        return changed

    def delete_run(self, principal: EvidencePrincipal, run_id: str, *, confirmation: str) -> dict[str, Any]:
        target = EvidenceScope(
            principal.scope.tenant_id, principal.scope.subject_id,
            principal.scope.workspace_id, run_id,
        )
        try:
            principal.authorize(EvidenceOperation.DELETE, target)
            if confirmation != f"DELETE {run_id}":
                raise PermissionError("evidence deletion requires exact confirmation")
            with self._store() as store:
                for document in store.documents():
                    if document.get("record_type") == "continuity" and document["workflow"]["workflow_id"] == run_id:
                        actual = EvidenceScope(**document["workflow"]["scope"])
                        principal.authorize(EvidenceOperation.DELETE, EvidenceScope(actual.tenant_id, actual.subject_id, actual.workspace_id, run_id))
                result = store.delete_run(run_id)
                store.access_event(self._audit(principal, "delete", target, True, **result))
            return {"run_id": run_id, "deleted": result}
        except PermissionError:
            self._record_access(principal, "delete", target, False)
            raise

    @_key_transition
    def rotate_key(self, principal: EvidencePrincipal, *, confirmation: str) -> dict[str, Any]:
        target = principal.scope
        try:
            principal.authorize(EvidenceOperation.ROTATE, target)
            if confirmation != "ROTATE EVIDENCE KEY":
                raise PermissionError("key rotation requires exact confirmation")
            if self._key is None:
                raise PermissionError("evidence vault is locked")
            old_key = self._key
            new_key = os.urandom(32)
            self._write_rotation_journal(new_key)
            with self._store() as store:
                result = store.rotate_key(new_key)
            try:
                from atmem.control.store import reencrypt_control_container

                control_path = self.root / "evidence.db"
                if control_path.exists():
                    reencrypt_control_container(control_path, old_key, new_key)
                write_key(self.key_path, new_key, replace=True)
            except Exception:
                with EncryptedEvidenceStore(self.vault_path, new_key) as store:
                    store.rotate_key(old_key)
                if control_path.exists():
                    reencrypt_control_container(control_path, new_key, old_key)
                raise
            self._key = new_key
            self.rotation_path.unlink(missing_ok=True)
            self._record_access(principal, "rotate", target, True, **result)
            return {"rotated": True, **result}
        except PermissionError:
            self._record_access(principal, "rotate", target, False)
            raise

    @_key_transition
    def lock(self, principal: EvidencePrincipal, *, confirmation: str) -> dict[str, Any]:
        target = principal.scope
        principal.authorize(EvidenceOperation.LOCK, target)
        if confirmation != "LOCK EVIDENCE":
            raise PermissionError("locking evidence requires exact confirmation")
        if self._key is None:
            return self.protection_status()
        self._record_access(principal, "lock", target, True)
        nonce, ciphertext = seal_json(
            self._identity_key,
            f"locked-key:{self.vault_id}",
            {"format": "atmem-locked-evidence-key-v1", "key": base64.b64encode(self._key).decode()},
        )
        descriptor = os.open(self.locked_key_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(
                {"format": "atmem-locked-evidence-key-wrapper-v1", "nonce": base64.b64encode(nonce).decode(), "ciphertext": base64.b64encode(ciphertext).decode()},
                handle,
                separators=(",", ":"),
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        self.key_path.unlink()
        self._key = None
        return self.protection_status()

    @_key_transition
    def unlock(self, principal: EvidencePrincipal, *, confirmation: str) -> dict[str, Any]:
        target = principal.scope
        principal.authorize(EvidenceOperation.UNLOCK, target)
        if confirmation != "UNLOCK EVIDENCE":
            raise PermissionError("unlocking evidence requires exact confirmation")
        if self._key is not None:
            return self.protection_status()
        if not self.locked_key_path.is_file():
            raise PermissionError("no application-locked evidence key is available")
        wrapper = json.loads(self.locked_key_path.read_text(encoding="utf-8"))
        value = open_json(
            self._identity_key,
            f"locked-key:{self.vault_id}",
            base64.b64decode(wrapper["nonce"], validate=True),
            base64.b64decode(wrapper["ciphertext"], validate=True),
        )
        candidate = base64.b64decode(value["key"], validate=True)
        if not self._key_opens_vault(candidate):
            raise PermissionError("locked evidence key does not open this vault")
        write_key(self.key_path, candidate)
        self._key = candidate
        self.locked_key_path.unlink()
        self._record_access(principal, "unlock", target, True)
        return self.protection_status()

    def plaintext_export(
        self,
        principal: EvidencePrincipal,
        run_id: str,
        *,
        confirmation: str,
    ) -> bytes:
        return b"".join(
            self.iter_plaintext_export(
                principal, run_id, confirmation=confirmation
            )
        )

    def iter_plaintext_export(
        self,
        principal: EvidencePrincipal,
        run_id: str,
        *,
        confirmation: str,
    ) -> Iterator[bytes]:
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            run_id,
        )
        try:
            principal.authorize(EvidenceOperation.PLAINTEXT_EXPORT, target)
            if confirmation != f"EXPORT {run_id}":
                raise PermissionError("plaintext export requires exact confirmation")
            def stream() -> Iterator[bytes]:
                digest = sha256()
                complete = False
                try:
                    opening = b"[\n"
                    digest.update(opening)
                    yield opening
                    first = True
                    with self._store() as store:
                        for item in store.documents():
                            if item.get("record_type") != "evidence":
                                continue
                            envelope = dict(item.get("envelope") or {})
                            if (
                                str(envelope.get("run_id") or "") != run_id
                                or not principal.scope.permits(self._scope_from_envelope(envelope))
                            ):
                                continue
                            materialized = self._materialize_artifacts(item)
                            chunk = (("" if first else ",\n") + json.dumps(materialized, sort_keys=True)).encode()
                            first = False
                            digest.update(chunk)
                            yield chunk
                    closing = b"\n]\n"
                    digest.update(closing)
                    yield closing
                    complete = True
                finally:
                    self._record_access(
                        principal,
                        "plaintext_export",
                        target,
                        complete,
                        sha256=digest.hexdigest() if complete else None,
                        interrupted=not complete,
                    )
            return stream()
        except PermissionError:
            self._record_access(principal, "plaintext_export", target, False)
            raise

    def recipient_export(
        self,
        principal: EvidencePrincipal,
        run_id: str,
        *,
        recipient_public_key: bytes,
        signing_secret_key: bytes,
        signing_public_key: bytes,
    ) -> dict[str, Any]:
        target = EvidenceScope(
            principal.scope.tenant_id,
            principal.scope.subject_id,
            principal.scope.workspace_id,
            run_id,
        )
        try:
            principal.authorize(EvidenceOperation.ENCRYPTED_EXPORT, target)
            content = canonical_json(self.events(principal, run_id)).encode()
            bundle = encrypted_export(
                content,
                recipient_public_key=recipient_public_key,
                signing_secret_key=signing_secret_key,
                signing_public_key=signing_public_key,
            )
            self._record_access(principal, "encrypted_export", target, True)
            return bundle
        except PermissionError:
            self._record_access(principal, "encrypted_export", target, False)
            raise

    def create_demo_accounts(self, *, subject_id: str) -> list[dict[str, str]]:
        return self.accounts.create_demo_accounts(
            EvidenceScope("local", subject_id)
        )

    def authenticate(self, token: str) -> EvidencePrincipal | None:
        return self.accounts.authenticate(token)

    def _artifact_vault(self) -> ArtifactVault:
        if self._key is None:
            raise PermissionError("encrypted evidence is locked")
        return ArtifactVault(self.artifact_root, self._artifact_key)

    def _externalize_artifacts(self, value: Any) -> Any:
        """Replace exact inline binary parts with durable encrypted references."""

        if isinstance(value, list):
            return [self._externalize_artifacts(item) for item in value]
        if not isinstance(value, dict):
            return value
        # Keep the inline value inside the already encrypted evidence document as
        # the disaster-recovery authority. The separate artifact vault supplies
        # content addressing/deduplication and can be rebuilt from this copy.
        result = {
            str(key): self._externalize_artifacts(item)
            for key, item in value.items()
        }
        encoded = value.get("data_base64")
        if isinstance(encoded, str):
            try:
                plaintext = base64.b64decode(encoded, validate=True)
            except Exception as exc:
                raise ValueError("exact artifact data_base64 is invalid") from exc
            reference = self._artifact_vault().put_bytes(plaintext)
            result["artifact"] = reference
            result["artifact_capture"] = "encrypted_exact"
        elif "data_base64" in value:
            raise ValueError("exact artifact data_base64 must be a base64 string")
        return result

    def _materialize_artifacts(self, value: Any) -> Any:
        """Return exact bytes only after the caller passed evidence authorization."""

        if isinstance(value, list):
            return [self._materialize_artifacts(item) for item in value]
        if not isinstance(value, dict):
            return value
        result = {str(key): self._materialize_artifacts(item) for key, item in value.items()}
        reference = value.get("artifact")
        if isinstance(reference, dict) and reference.get("format") == "atmem-artifact-reference-v1":
            digest = str(reference.get("plaintext_sha256") or "")
            try:
                plaintext = self._artifact_vault().read(digest)
            except FileNotFoundError:
                encoded = value.get("data_base64")
                if not isinstance(encoded, str):
                    raise
                plaintext = base64.b64decode(encoded, validate=True)
                result["artifact_recovery"] = "inline_encrypted_evidence"
            if len(plaintext) != int(reference.get("plaintext_bytes") or -1):
                raise ValueError("artifact byte count does not match its evidence reference")
            if sha256(plaintext).hexdigest() != digest:
                raise ValueError("artifact digest does not match its evidence reference")
            result["data_base64"] = base64.b64encode(plaintext).decode("ascii")
        return result

    def _record_access(
        self,
        principal: EvidencePrincipal,
        operation: str,
        target: EvidenceScope,
        allowed: bool,
        **detail: Any,
    ) -> None:
        with self._store() as store:
            store.access_event(self._audit(principal, operation, target, allowed, **detail))

    @staticmethod
    def _audit(
        principal: EvidencePrincipal,
        operation: str,
        target: EvidenceScope,
        allowed: bool,
        **detail: Any,
    ) -> dict[str, Any]:
        return {
            "principal_id": principal.principal_id,
            "role": principal.role.value,
            "operation": operation,
            "target_scope": target.to_dict(),
            "allowed": allowed,
            "detail": detail,
        }

    @staticmethod
    def _scope_from_envelope(envelope: dict[str, Any]) -> EvidenceScope:
        return EvidenceScope(
            tenant_id=str(envelope.get("tenant_id") or "local"),
            subject_id=str(envelope.get("subject_id") or "local-user"),
            workspace_id=str(envelope.get("workspace_id")) if envelope.get("workspace_id") else None,
            run_id=str(envelope.get("run_id")) if envelope.get("run_id") else None,
        )
