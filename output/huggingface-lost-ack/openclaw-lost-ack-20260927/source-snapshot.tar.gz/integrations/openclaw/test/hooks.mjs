#!/usr/bin/env node
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { chmodSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import path from "node:path";

import plugin from "../dist/index.js";
import { AtmemClient } from "../dist/src/rpc-client.js";

const repoRoot = path.resolve(import.meta.dirname, "../../..");
process.env.PYTHONPATH = [repoRoot, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter);

function fakeApi(config, toolContext = {}) {
  const hooks = new Map();
  const tools = new Map();
  const services = [];
  const logs = [];
  const logger = {
    debug(message) { logs.push(String(message)); },
    info(message) { logs.push(String(message)); },
    warn(message) { logs.push(String(message)); },
    error(message) { logs.push(String(message)); },
  };
  const api = {
    pluginConfig: config,
    logger,
    on(name, handler) { hooks.set(name, handler); },
    registerTool(spec) {
      if (typeof spec === "function") {
        const tool = spec({
          sessionKey: "takeover-1",
          senderIsOwner: true,
          activeModel: { provider: "openai", modelId: "test-model" },
          ...toolContext,
        });
        tools.set(tool.name, tool);
        return;
      }
      tools.set(spec.name, spec);
    },
    registerService(service) { services.push(service); },
  };
  plugin.register(api);
  return { hooks, tools, services, logs };
}

function controlCli(...args) {
  const result = spawnSync("atmem", ["control", ...args, "--json"], {
    encoding: "utf8",
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  return result.stdout.trim() ? JSON.parse(result.stdout) : null;
}

function blackboxCli(...args) {
  const result = spawnSync("python", ["-m", "atmem.cli", "blackbox", ...args, "--json"], {
    encoding: "utf8",
    cwd: repoRoot,
    env: { ...process.env, PYTHONPATH: repoRoot },
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  return result.stdout.trim() ? JSON.parse(result.stdout) : null;
}

function evidenceCli(...args) {
  const result = spawnSync("python", ["-m", "atmem.cli", "evidence", ...args], {
    encoding: "utf8",
    cwd: repoRoot,
    env: { ...process.env, PYTHONPATH: repoRoot },
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  return result.stdout.trim() ? JSON.parse(result.stdout) : null;
}


const dataDir = mkdtempSync(path.join(tmpdir(), "atmem-hooks-"));
const dbPath = path.join(dataDir, "memory.db");
const mediaRoot = path.join(dataDir, "openclaw-media");
mkdirSync(mediaRoot);
mkdirSync(path.join(mediaRoot, "inbound"));
process.env.ATMEM_OPENCLAW_MEDIA_ROOT = mediaRoot;
const base = {
  command: "atmem",
  commandArgs: ["mcp", "--db", dbPath, "--subject", "hook-user"],
  dbPath,
  subject: "hook-user",
  recall: { enabled: true, maxRecords: 3, maxChars: 1200, minScore: 0.3, timeoutMs: 5000 },
  persona: { enabled: true, maxChars: 600, ttlSeconds: 3600 },
  capture: { enabled: true, captureAssistant: false },
  cacheAware: { enabled: true, compactReferences: true },
  tools: { enabled: true },
};

const missingEngine = new AtmemClient({
  command: `atmem-deliberately-missing-${process.pid}`,
  args: ["mcp"],
  defaultTimeoutMs: 1000,
});
await assert.rejects(
  missingEngine.hasTool("memory_recall"),
  /engine executable .* was not found.*Install the engine first.*pip install atmem/s,
);
missingEngine.close();

// Closing and immediately reconnecting must not let the old child's delayed
// exit event tear down the replacement process.
const reconnectClient = new AtmemClient({
  command: "atmem",
  args: ["mcp", "--db", dbPath, "--subject", "reconnect-user"],
  idleTimeoutMs: 60_000,
});
await reconnectClient.connect();
reconnectClient.close();
const reconnectResult = await reconnectClient.callTool("memory_recall", {
  query: "reconnect probe",
  limit: 1,
});
assert.ok(Array.isArray(reconnectResult));
reconnectClient.close();

const runtime = fakeApi(base);
const beforePrompt = runtime.hooks.get("before_prompt_build");
const agentEnd = runtime.hooks.get("agent_end");
const beforeWrite = runtime.hooks.get("before_message_write");

try {
  // Six memory tools plus Amendment A's two governed-task tools. The task
  // tools have to be registered here, with the same mechanism as memory_search:
  // a control-plane operation the model cannot see is a checklist the agent
  // cannot tick.
  assert.equal(runtime.tools.size, 8);
  assert.ok(runtime.tools.has("task_report_progress"));
  assert.ok(runtime.tools.has("task_binding_status"));

  const observe = runtime.tools.get("atmem_observe");
  const attachmentBytes = Buffer.from("exact uploaded image bytes");
  const attachmentPath = path.join(mediaRoot, "upload.png");
  writeFileSync(attachmentPath, attachmentBytes);
  const messageReceived = runtime.hooks.get("message_received");
  await messageReceived(
    {
      content: "Analyze this upload",
      sessionKey: "takeover-1",
      runId: "current-media-run-1",
      media: [{ path: attachmentPath, contentType: "image/png", kind: "image" }],
    },
    { sessionKey: "takeover-1", runId: "current-media-run-1" },
  );
  // Current OpenClaw may subsequently emit a sparse transcript write. Before
  // this regression fix that second hook erased the valid media binding.
  beforeWrite({
    message: {
      role: "user",
      content: "Analyze this upload",
      idempotencyKey: "current-media-run-1:user",
    },
  }, { sessionKey: "takeover-1" });
  const currentMediaRuntime = fakeApi(base, { runId: "current-media-run-1" });
  const autoObserved = await currentMediaRuntime.tools.get("atmem_observe").execute("observe-auto-1", {
    text: "The upload contains a geometric logo.",
    modality: "image",
    segment: { region: "whole image", dimensions: { width: 640, height: 480 } },
  });
  assert.equal(autoObserved.details.status, "quarantined");
  assert.equal(autoObserved.details.provenanceSource, "openclaw-upload");
  assert.equal(
    autoObserved.details.mediaSha256,
    createHash("sha256").update(attachmentBytes).digest("hex"),
  );
  for (const service of currentMediaRuntime.services) await service.stop?.();

  // A staging event can expose a safe host-managed original path before the
  // normalized media list is ready. Capture it immediately rather than
  // replacing it with the caption placeholder or waiting for a later process.
  const originalBytes = Buffer.from("exact original staged image bytes");
  const originalPath = path.join(mediaRoot, "original-staged.png");
  writeFileSync(originalPath, originalBytes);
  await messageReceived(
    {
      content: "[User sent media without caption]",
      sessionKey: "original-media-session",
      runId: "original-media-run-1",
      originalMedia: [{ path: originalPath, contentType: "image/png", kind: "image" }],
      mediaStagingPending: true,
    },
    { sessionKey: "original-media-session", runId: "original-media-run-1" },
  );
  const originalRuntime = fakeApi(base, { runId: "original-media-run-1" });
  try {
    const observed = await originalRuntime.tools.get("atmem_observe").execute(
      "observe-original-media-1",
      { text: "The staged image has a visible outline.", modality: "image" },
    );
    assert.equal(
      observed.details.mediaSha256,
      createHash("sha256").update(originalBytes).digest("hex"),
    );
  } finally {
    for (const service of originalRuntime.services) await service.stop?.();
  }

  // OpenClaw can execute the inbound hook and the later agent tool in
  // separate plugin runtimes. The trusted upload binding must survive that
  // boundary instead of depending on one process-local Map.
  const separateRuntime = fakeApi(base);
  try {
    const crossRuntimeObserved = await separateRuntime.tools
      .get("atmem_observe")
      .execute("observe-cross-runtime-1", {
        text: "The separately executed tool can resolve the geometric logo upload.",
        modality: "image",
      });
    assert.equal(crossRuntimeObserved.details.status, "quarantined");
    assert.equal(crossRuntimeObserved.details.provenanceSource, "openclaw-upload");
    assert.equal(crossRuntimeObserved.details.mediaSha256, autoObserved.details.mediaSha256);
  } finally {
    for (const service of separateRuntime.services) await service.stop?.();
  }

  // Internal OpenClaw webchat does not broadcast message_received, and its
  // prompt hooks intentionally omit local attachment paths. The synchronous
  // transcript hook receives the current user message with canonical
  // MediaPath fields before the model can call tools, so it establishes the
  // trusted binding without scraping text or guessing the newest file.
  const webchatBytes = Buffer.from("exact webchat image bytes");
  const webchatPath = path.join(mediaRoot, "webchat-upload.png");
  writeFileSync(webchatPath, webchatBytes);
  const webchatPrompt = "Remember this webchat upload for later.";
  beforeWrite({
    message: {
      role: "user",
      content: webchatPrompt,
      idempotencyKey: "webchat-run-1:user",
      MediaPath: webchatPath,
      MediaPaths: [webchatPath],
      MediaType: "image/png",
      MediaTypes: ["image/png"],
    },
  }, { sessionKey: "takeover-1" });
  const webchatRuntime = fakeApi(base, { runId: "webchat-run-1" });
  try {
    const webchatObserved = await webchatRuntime.tools
      .get("atmem_observe")
      .execute("observe-webchat-runtime-1", {
        text: "The webchat upload is available through trusted structured metadata.",
        modality: "image",
      });
    assert.equal(webchatObserved.details.status, "quarantined");
    assert.equal(webchatObserved.details.success, true);
    assert.equal(webchatObserved.details.provenanceSource, "openclaw-upload");
    assert.equal(
      webchatObserved.details.mediaSha256,
      createHash("sha256").update(webchatBytes).digest("hex"),
    );
  } finally {
    for (const service of webchatRuntime.services) await service.stop?.();
  }

  const forgetArtifact = runtime.tools.get("atmem_forget_artifact");
  const artifactForgotten = await forgetArtifact.execute("forget-artifact-1", {
    media_sha256: autoObserved.details.mediaSha256,
    artifact_id: autoObserved.details.artifactId,
  });
  assert.equal(artifactForgotten.details.deleted, true);
  await messageReceived(
    { content: "A later text-only turn", sessionKey: "takeover-1", metadata: {} },
    { sessionKey: "takeover-1" },
  );
  await assert.rejects(
    observe.execute("observe-stale-1", {
      text: "This must not reuse the previous upload.",
      modality: "image",
    }),
    /No exact uploaded-file provenance is bound/,
  );

  await beforePrompt({ prompt: "My favorite color is teal." }, { sessionKey: "capture-1" });
  await agentEnd({ success: true, messages: [] }, { sessionKey: "capture-1" });

  const injected = await beforePrompt(
    { prompt: "What is my favorite color?" },
    { sessionKey: "recall-1" },
  );
  assert.equal(injected.prependContext, undefined);
  assert.ok(injected.appendSystemContext.includes("<user_persona>"));
  assert.equal(injected.appendContext, undefined, "persona records must not repeat in recall");
  assert.ok(injected.appendSystemContext.includes("teal"));
  assert.match(injected.appendSystemContext, /\[m:[a-f0-9]{8}\]/);
  assert.doesNotMatch(injected.appendSystemContext, /\[rec_[a-f0-9]+\]/);
  const selectiveRuntime = fakeApi({ ...base, persona: undefined });
  try {
    const selective = await selectiveRuntime.hooks.get("before_prompt_build")(
      { prompt: "favorite color" }, { sessionKey: "selective-recall" });
    assert.ok(selective.appendContext.includes("teal"));
    assert.ok(!selective.appendSystemContext?.includes("<user_persona>"));
    const unrelated = await selectiveRuntime.hooks.get("before_prompt_build")(
      { prompt: "list all chinese shops in botany road selling roasted duck" },
      { sessionKey: "selective-unrelated" });
    assert.ok(!JSON.stringify(unrelated || {}).includes("teal"));
  } finally {
    for (const service of selectiveRuntime.services) await service.stop?.();
  }

  const compatibleSearch = runtime.tools.get("memory_search");
  const searchResult = await compatibleSearch.execute("compat-search-1", {
    query: "favorite color",
    maxResults: 5,
  });
  const searchPayload = JSON.parse(searchResult.content[0].text);
  assert.ok(searchPayload.results.length >= 1);
  assert.match(searchPayload.results[0].path, /^atmem:\/\/record\/rec_/);
  assert.equal(typeof searchPayload.results[0].score, "number");

  const compatibleGet = runtime.tools.get("memory_get");
  const getResult = await compatibleGet.execute("compat-get-1", {
    path: searchPayload.results[0].path,
    from: 1,
    lines: 10,
  });
  const getPayload = JSON.parse(getResult.content[0].text);
  assert.ok(getPayload.text.includes("teal"));
  assert.equal(getResult.details.found, true);

  await beforePrompt(
    { prompt: "Actually, use blue as my favorite color going forward." },
    { sessionKey: "capture-2" },
  );
  await agentEnd({ success: true, messages: [] }, { sessionKey: "capture-2" });
  const corrected = await beforePrompt(
    { prompt: "What is my favorite color?" },
    { sessionKey: "recall-2" },
  );
  assert.ok(corrected.appendSystemContext.includes("blue"));
  assert.ok(!corrected.appendSystemContext.includes("teal"));

  const forget = runtime.tools.get("atmem_forget");
  const forgotten = await forget.execute("forget-1", {
    utterance: "Forget my favorite color.",
  });
  assert.equal(forgotten.details.deleted, true);
  const afterForget = await beforePrompt(
    { prompt: "What is my favorite color?" },
    { sessionKey: "recall-3" },
  );
  assert.equal(afterForget?.appendSystemContext, undefined);
  assert.equal(afterForget?.appendContext, undefined);

  const cleaned = beforeWrite({
    message: {
      role: "user",
      content:
        "Question\n<user_persona>\n- private\n</user_persona>\n" +
        "<relevant_memories>\n- private\n</relevant_memories>",
    },
  });
  assert.equal(cleaned.message.content, "Question");

  const toolFree = fakeApi({ ...base, tools: { enabled: false } });
  assert.equal(toolFree.tools.size, 0);
  for (const service of toolFree.services) await service.stop?.();

  const legacy = fakeApi({
    ...base,
    dbPath: path.join(dataDir, "legacy.db"),
    commandArgs: ["mcp", "--db", path.join(dataDir, "legacy.db"), "--subject", "legacy"],
    cacheAware: { enabled: false, compactReferences: false },
    tools: { enabled: false },
  });
  const legacyBefore = legacy.hooks.get("before_prompt_build");
  const legacyEnd = legacy.hooks.get("agent_end");
  await legacyBefore({ prompt: "My home city is Sydney." }, { sessionKey: "legacy-capture" });
  await legacyEnd({ success: true, messages: [] }, { sessionKey: "legacy-capture" });
  const legacyInjection = await legacyBefore(
    { prompt: "What is my home city?" },
    { sessionKey: "legacy-recall" },
  );
  assert.ok(legacyInjection.prependContext.includes("Sydney"));
  assert.equal(legacyInjection.appendContext, undefined);
  assert.equal(legacyInjection.appendSystemContext, undefined);
  for (const service of legacy.services) await service.stop?.();

  // Delegated context is an exclusive, exact prepend contribution. The
  // adapter keeps it only until llm_input proves one exact occurrence.
  const delegatedLog = path.join(dataDir, "delegated-rpc.jsonl");
  const delegatedServer = path.join(dataDir, "delegated-mcp.py");
  const exactDelegated = "Reviewed context 🧠\r\nKeep these bytes.";
  const exactTask = "<<<atmem-governed-task-data>>>\ntask: task-1\nremaining: verify\n<<<end-atmem-governed-task-data>>>";
  writeFileSync(delegatedServer, `#!/usr/bin/env python3
import json, sys
LOG = ${JSON.stringify(delegatedLog)}
EXACT = ${JSON.stringify(exactDelegated)}
TASK = ${JSON.stringify(exactTask)}
for line in sys.stdin:
    request = json.loads(line)
    if request.get("method") == "notifications/initialized":
        continue
    if request.get("method") == "initialize":
        result = {"protocolVersion":"2025-06-18","capabilities":{},"serverInfo":{"name":"fake","version":"1"}}
    elif request.get("method") == "tools/call":
        params = request.get("params") or {}
        name = params.get("name")
        with open(LOG, "a", encoding="utf-8") as handle:
            handle.write(json.dumps({"name": name, "arguments": params.get("arguments")}, separators=(",", ":")) + "\\n")
        if name == "control_prepare_task_context":
            # Models the real contract: identity resolves through an explicit
            # task id or a registered binding, and anything else withholds with
            # zero task-state bytes. Session "task" stands in for a bound
            # conversation; every other session is unbound.
            arguments = params.get("arguments") or {}
            bound = arguments.get("session_key") == "task"
            if arguments.get("task_id") or bound:
                value = {"disposition":"injected","context":TASK,"context_sha256":"sha256:${createHash("sha256").update(exactTask).digest("hex")}","delivery_id":"task-delivery-1","revision":4,"reason_codes":[],"task_id":arguments.get("task_id") or "task-1"}
            else:
                value = {"disposition":"withheld","context":"","context_sha256":None,"delivery_id":None,"revision":1,"reason_codes":["task_context_selection_required"],"task_id":None}
        elif name == "control_prepare":
            arguments = params.get("arguments") or {}
            query = arguments.get("query") or ""
            if not arguments.get("user_id"):
                value = {"inject":False,"context":"","authority":"delegated","decision":"provider_failure","mode":"active","candidate_ids":[],"reason":"missing authenticated user"}
            elif "Australia" in query:
                value = {"inject":False,"context":"","authority":"atmem","decision":"no_useful_memory","mode":"active","candidate_ids":[],"retrieval":{"decision":{"format":"atmem-retrieval-decision-v1","calibration_version":"retrieval-calibration-v1","support_class":"no_useful_memory","ranked_record_ids":[],"candidates":[],"reason_codes":["no_relevance_signal"]}}}
            elif "withhold" in query:
                value = {"inject":False,"context":"","authority":"delegated","decision":"withhold","mode":"active","candidate_ids":[],"context_receipt_id":"receipt-withhold"}
            elif "reject" in query:
                value = {"inject":False,"context":"","authority":"delegated","decision":"provider_failure","mode":"active","candidate_ids":[],"reason":"signature verification failed"}
            elif "corrupt" in query:
                value = {"inject":True,"context":EXACT,"context_sha256":"${"0".repeat(64)}","authority":"delegated","decision":"inject","result_sha256":"${"e".repeat(64)}","exposure_id":"delivery-corrupt","context_receipt_id":"receipt-corrupt","receipt":{"id":"receipt-corrupt","sha256":"${"f".repeat(64)}"},"provider":{"id":"fixture-provider","version":"test","instance_id":"local"},"mode":"active","candidate_ids":[]}
            elif "fallback" in query:
                value = {"inject":True,"context":"native fallback context","authority":"atmem_fallback","decision":"native_context","native_fallback":True,"mode":"active","candidate_ids":["native-1"]}
            else:
                value = {"inject":True,"context":EXACT,"context_sha256":"${createHash("sha256").update(exactDelegated).digest("hex")}","authority":"delegated","decision":"inject","result_sha256":"${"c".repeat(64)}","exposure_id":"delivery-1","context_receipt_id":"receipt-1","receipt":{"id":"receipt-1","sha256":"${"d".repeat(64)}"},"provider":{"id":"fixture-provider","version":"test","instance_id":"local"},"mode":"active","candidate_ids":[]}
        elif name == "control_record_blackbox_event":
            value = {"durably_accepted": True, "decision": "accepted"}
        else:
            value = {"ok": True}
        result = {"content":[{"type":"text","text":json.dumps(value, separators=(",", ":"))}],"isError":False}
    else:
        result = {}
    print(json.dumps({"jsonrpc":"2.0","id":request.get("id"),"result":result}, separators=(",", ":")), flush=True)
`);
  chmodSync(delegatedServer, 0o700);
  const delegatedRuntime = fakeApi({
    ...base,
    command: delegatedServer,
    controlPlane: { enabled: true, statePath: path.join(dataDir, "unused-state.json") },
    agentWorkspaces: { main: path.join(dataDir, "delegated-workspace") },
    delegatedContext: { userId: "owner", requireOwner: true },
  });
  const delegatedCtx = {
    agentId: "main",
    sessionKey: "delegated-session",
    sessionId: "delegated-session",
    runId: "delegated-run",
    senderIsOwner: true,
  };
  const delegatedInsertion = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "What context should I use?" },
    delegatedCtx,
  );
  assert.equal(delegatedInsertion.prependContext, exactDelegated);
  assert.equal(delegatedInsertion.appendContext, undefined);
  const delegatedModelInput = {
    runId: "delegated-run",
    sessionId: "delegated-session",
    provider: "anthropic",
    model: "test",
    prompt: exactDelegated + "\nWhat context should I use?",
    historyMessages: [],
    imagesCount: 0,
    tools: [],
  };
  await delegatedRuntime.hooks.get("llm_input")(delegatedModelInput, delegatedCtx);
  await delegatedRuntime.hooks.get("llm_input")(delegatedModelInput, delegatedCtx);
  // before_prompt_build has no event session fallback. Confirmation must use
  // the same ctx/run-derived key even when llm_input alone carries sessionId.
  const eventOnlyCtx = {
    agentId: "main",
    runId: "event-only-run",
    senderIsOwner: true,
  };
  const eventOnlyInsertion = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "Confirm using the event-only session." },
    eventOnlyCtx,
  );
  assert.equal(eventOnlyInsertion.prependContext, exactDelegated);
  await delegatedRuntime.hooks.get("llm_input")(
    {
      ...delegatedModelInput,
      runId: "event-only-run",
      sessionId: "event-only-session",
      prompt: exactDelegated + "\nConfirm using the event-only session.",
    },
    eventOnlyCtx,
  );
  const missingPendingWarning = "exact delegated delivery confirmation is unavailable";
  const warningsBeforeEmpty = delegatedRuntime.logs.filter((line) =>
    line.includes(missingPendingWarning)
  ).length;
  const emptyCtx = { ...delegatedCtx, sessionKey: "empty", sessionId: "empty", runId: "empty" };
  const emptyInsertion = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "" },
    emptyCtx,
  );
  assert.equal(emptyInsertion, undefined);
  await delegatedRuntime.hooks.get("llm_input")(
    { ...delegatedModelInput, runId: "empty", sessionId: "empty", prompt: "" },
    emptyCtx,
  );
  assert.equal(
    delegatedRuntime.logs.filter((line) => line.includes(missingPendingWarning)).length,
    warningsBeforeEmpty,
  );
  const withheld = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "withhold this turn" },
    { ...delegatedCtx, sessionKey: "withhold", sessionId: "withhold", runId: "withhold" },
  );
  assert.equal(withheld, undefined);
  const unrelated = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "what cars are available in Australia?" },
    { ...delegatedCtx, sessionKey: "cars", sessionId: "cars", runId: "cars" },
  );
  assert.equal(unrelated, undefined);
  const rejected = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "reject invalid signed result" },
    { ...delegatedCtx, sessionKey: "reject", sessionId: "reject", runId: "reject" },
  );
  assert.equal(rejected, undefined);
  const corrupt = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "corrupt local handoff" },
    { ...delegatedCtx, sessionKey: "corrupt", sessionId: "corrupt", runId: "corrupt" },
  );
  assert.equal(corrupt, undefined);
  const fallback = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "fallback this turn" },
    { ...delegatedCtx, sessionKey: "fallback", sessionId: "fallback", runId: "fallback" },
  );
  assert.equal(fallback.appendContext, "native fallback context");
  assert.equal(fallback.prependContext, undefined);
  const taskCtx = { ...delegatedCtx, taskId: "task-1", sessionKey: "task", sessionId: "task", runId: "task" };
  const taskInsertion = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "Continue the exact governed task" },
    taskCtx,
  );
  assert.equal(taskInsertion.prependContext, exactDelegated);
  assert.equal(taskInsertion.appendContext, exactTask);
  await delegatedRuntime.hooks.get("agent_end")(
    { success: true, messages: [], runId: "task" },
    taskCtx,
  );
  const taskOnlyCtx = {
    ...delegatedCtx,
    taskId: "task-1",
    sessionKey: "task-only",
    sessionId: "task-only",
    runId: "task-only",
  };
  const taskOnlyInsertion = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "withhold memory but continue the governed task" },
    taskOnlyCtx,
  );
  assert.equal(taskOnlyInsertion.prependContext, undefined);
  assert.equal(taskOnlyInsertion.appendContext, exactTask);
  await delegatedRuntime.hooks.get("agent_end")(
    { success: true, messages: [], runId: "task-only" },
    taskOnlyCtx,
  );
  const missingOwner = await delegatedRuntime.hooks.get("before_prompt_build")(
    { prompt: "missing owner" },
    { ...delegatedCtx, sessionKey: "missing", sessionId: "missing", runId: "missing", senderIsOwner: false },
  );
  assert.equal(missingOwner, undefined);
  const delegatedCalls = readFileSync(delegatedLog, "utf8")
    .split("\n")
    .filter(Boolean)
    .map((line) => JSON.parse(line));
  assert.equal(JSON.stringify(delegatedCalls).includes(exactDelegated), false);
  assert.equal(
    delegatedCalls.filter((row) =>
      row.name === "control_record_blackbox_event" &&
      row.arguments?.event_type === "context.injected"
    ).length,
    2,
  );
  const authorizationEvents = delegatedCalls.filter((row) =>
    row.name === "control_record_blackbox_event" &&
    row.arguments?.event_type === "context.provider_authorization"
  );
  assert.equal(authorizationEvents.length, 8);
  assert.equal(authorizationEvents[0].arguments.context_receipt_id, "receipt-1");
  assert.equal(
    delegatedCalls.filter((row) => row.name === "control_prepare").length,
    10,
  );
  const taskDisposition = delegatedCalls.find((row) =>
    row.name === "control_record_blackbox_event" &&
    row.arguments?.event_type === "context.disposition" &&
    row.arguments?.run_id === "task"
  );
  const exactEnvelopeSha256 = createHash("sha256")
    .update(JSON.stringify({ appendContext: exactTask, prependContext: exactDelegated }))
    .digest("hex");
  assert.equal(
    taskDisposition.arguments.payload.context_envelope_sha256,
    exactEnvelopeSha256,
  );
  assert.equal(
    taskDisposition.arguments.payload.context_location,
    "prependContext+appendContext",
  );
  const taskOnlyDisposition = delegatedCalls.find((row) =>
    row.name === "control_record_blackbox_event" &&
    row.arguments?.event_type === "context.disposition" &&
    row.arguments?.run_id === "task-only"
  );
  const taskContextSha256 = createHash("sha256").update(exactTask).digest("hex");
  const taskOnlyEnvelopeSha256 = createHash("sha256")
    .update(JSON.stringify({ appendContext: exactTask }))
    .digest("hex");
  assert.equal(taskOnlyDisposition.arguments.payload.disposition, "injected");
  assert.equal(taskOnlyDisposition.arguments.payload.context_chars, exactTask.length);
  assert.equal(taskOnlyDisposition.arguments.payload.context_location, "appendContext");
  assert.equal(taskOnlyDisposition.arguments.payload.context_sha256, taskContextSha256);
  assert.equal(taskOnlyDisposition.arguments.payload.context_block_sha256, taskContextSha256);
  assert.equal(
    taskOnlyDisposition.arguments.payload.context_envelope_sha256,
    taskOnlyEnvelopeSha256,
  );
  // Resolution is attempted on every turn carrying a session identity, not
  // only when the host names a task: OpenClaw supplies no task identity of its
  // own, so a turn that never asks can never be delivered a bound task. What
  // stays scarce is *delivery* -- only the bound conversation gets bytes, which
  // the exposure count below asserts.
  const taskPrepareCalls = delegatedCalls.filter(
    (row) => row.name === "control_prepare_task_context",
  );
  assert.equal(taskPrepareCalls.length, 9);
  for (const call of taskPrepareCalls) {
    // Never a partial identity: all three parts or the bridge does not ask.
    assert.equal(call.arguments.host_type, "openclaw");
    assert.ok(call.arguments.session_key);
    assert.ok(call.arguments.session_epoch);
  }
  assert.equal(
    delegatedCalls.filter((row) => row.name === "control_task_exposure_shown").length,
    2,
  );
  assert.equal(
    delegatedCalls.filter((row) =>
      row.name === "control_record_blackbox_event" &&
      row.arguments?.event_type === "task.context.exposed"
    ).length,
    2,
  );
  assert.ok(delegatedRuntime.logs.some(line => line.includes("delegated_sender_not_owner")));
  const localWorkspace = path.join(dataDir, "delegated-workspace");
  const localRuntime = fakeApi({
    ...base, command: delegatedServer,
    controlPlane: { enabled: true, statePath: path.join(dataDir, "unused-state.json") },
    agentWorkspaces: { main: localWorkspace },
    delegatedContext: { userId: "owner", requireOwner: false, localOperator: {
      isolated: true, agentId: "main", workspaceDir: localWorkspace,
      sessionKey: "isolated", sessionId: "epoch-1",
    } },
  });
  try {
    const localCtx = { agentId: "main", workspaceDir: localWorkspace,
      sessionKey: "isolated", sessionId: "epoch-1", runId: "local-turn", messageProvider: "cli" };
    const insertion = await localRuntime.hooks.get("before_prompt_build")({ prompt: "local context" }, localCtx);
    assert.equal(insertion?.prependContext, exactDelegated);
    for (const patch of [{ senderIsOwner: false }, { channel: "discord" },
      { sessionId: "epoch-2" }, { workspaceDir: "/different" }, { messageProvider: undefined }]) {
      const denied = await localRuntime.hooks.get("before_prompt_build")({ prompt: "denied context" }, { ...localCtx, ...patch });
      assert.equal(denied, undefined);
    }
    // Both hook contracts can carry the invocation ID in context only.
    const toolCtx = { ...localCtx, toolCallId: "context-call" };
    await localRuntime.hooks.get("before_tool_call")({ toolName: "read", params: {} }, toolCtx);
    await localRuntime.hooks.get("after_tool_call")({ toolName: "read", params: {}, result: "observed" }, toolCtx);
    const rows = readFileSync(delegatedLog, "utf8").trim().split("\n").map(JSON.parse);
    const tools = rows.filter(row => row.arguments?.tool_call_id === "context-call");
    assert.deepEqual(tools.map(row => row.arguments.event_type), ["tool.requested", "tool.completed"]);
    assert.ok(tools.every(row => row.arguments.run_id === "local-turn"));
  } finally {
    for (const service of localRuntime.services) await service.stop?.();
  }
  for (const service of delegatedRuntime.services) await service.stop?.();

  const takeover = fakeApi({
    ...base,
    takeoverActive: true,
    nativeWorkspace: path.join(dataDir, "openclaw-workspace"),
  });
  const takeoverBefore = takeover.hooks.get("before_prompt_build");
  const guided = await takeoverBefore(
    { prompt: "What do I remember about my favorite color?" },
    { sessionKey: "takeover-1" },
  );
  assert.ok(guided.appendSystemContext.includes("<atmem_memory_provider>"));
  assert.ok(guided.appendSystemContext.includes("MEMORY.md and memory/*"));
  assert.ok(guided.appendSystemContext.includes("Use memory_search"));
  assert.ok(guided.appendSystemContext.includes("intentionally unavailable"));
  assert.ok(guided.appendSystemContext.includes("Never call Bash"));
  assert.ok(guided.appendSystemContext.includes("Interpret intent semantically"));
  assert.ok(guided.appendSystemContext.includes("If the user's meaning is both"));
  assert.ok(takeover.tools.has("memory_search"));
  assert.ok(takeover.tools.has("memory_get"));
  assert.ok(takeover.tools.has("memory_remember"));
  assert.equal(typeof takeover.hooks.get("before_model_resolve"), "function");
  await takeover.hooks.get("before_model_resolve")(
    { prompt: "I like blue cars", messages: [], queuedInjections: [] },
    {
      sessionKey: "agent:main:takeover-1",
      sessionId: "takeover-1",
      runId: "run-blue",
    },
  );
  const remembered = await takeover.tools.get("memory_remember").execute(
    "remember-blue",
    { fact: "User likes blue cars." },
  );
  const rememberedPayload = JSON.parse(remembered.content[0].text);
  assert.equal(rememberedPayload.stored, true);
  assert.equal(rememberedPayload.fact, "User likes blue cars.");
  const blueGet = await takeover.tools.get("memory_get").execute(
    "get-blue",
    { path: `atmem://record/${rememberedPayload.record_id}` },
  );
  assert.match(blueGet.content[0].text, /User likes blue cars\./);
  const beforeTool = takeover.hooks.get("before_tool_call");
  assert.equal(typeof beforeTool, "function");
  const workspace = path.join(dataDir, "openclaw-workspace");
  assert.equal(await beforeTool({
    toolName: "openclawmemory_search",
    params: { query: "my age", corpus: "memory", maxResults: 5 },
  }, {}), undefined);
  const blockedShell = await beforeTool({
    toolName: "Bash",
    params: { command: "sed -n '1,200p' MEMORY.md", cwd: workspace },
  }, {});
  assert.equal(blockedShell.block, true);
  assert.match(blockedShell.blockReason, /memory_remember/);
  const blockedWrite = await beforeTool({
    toolName: "write_file",
    params: { path: path.join(workspace, "memory", "today.md"), content: "note" },
    derivedPaths: [path.join(workspace, "memory", "today.md")],
  }, {});
  assert.equal(blockedWrite.block, true);
  const blockedPatch = await beforeTool({
    toolName: "apply_patch",
    params: { patch: "*** Update File: MEMORY.md\n+preference" },
  }, {});
  assert.equal(blockedPatch.block, true);
  assert.equal(await beforeTool({
    toolName: "Bash",
    params: { command: "pwd && git status", cwd: workspace },
  }, {}), undefined);
  assert.equal(await beforeTool({
    toolName: "write_file",
    params: { path: "/tmp/unrelated/MEMORY.md", content: "project notes" },
    derivedPaths: ["/tmp/unrelated/MEMORY.md"],
  }, {}), undefined);
  for (const service of takeover.services) await service.stop?.();

  const migrationState = path.join(dataDir, "control-plane.json");
  const migrationRoot = path.join(dataDir, "migrations");
  controlCli(
    "shadow",
    "--host",
    "openclaw",
    "--state",
    migrationState,
    "--control-root",
    migrationRoot,
    "--no-configure",
  );
  const disabledRecorder = fakeApi({
    ...base,
    controlPlane: {
      enabled: true,
      statePath: migrationState,
      blackboxEnabled: false,
    },
  });
  await disabledRecorder.hooks.get("before_model_resolve")(
    { runId: "run-blackbox-disabled", prompt: "Recorder is explicitly disabled." },
    { sessionId: "disabled-session", runId: "run-blackbox-disabled" },
  );
  await disabledRecorder.hooks.get("agent_end")(
    { runId: "run-blackbox-disabled", success: true, messages: [] },
    { sessionId: "disabled-session", runId: "run-blackbox-disabled" },
  );
  assert.equal(
    blackboxCli("runs", "--state", migrationState).runs.some(
      (run) => run.run_id === "run-blackbox-disabled",
    ),
    false,
  );
  for (const service of disabledRecorder.services) await service.stop?.();
  const controlPlane = fakeApi({
    ...base,
    commandArgs: ["mcp", "--db", path.join(dataDir, "must-not-be-used.db")],
    controlPlane: { enabled: true, statePath: migrationState },
    tools: { enabled: true },
  });
  assert.equal(controlPlane.tools.size, 0);
  const safeBefore = controlPlane.hooks.get("before_prompt_build");
  const safeEnd = controlPlane.hooks.get("agent_end");
  const blackboxCtx = {
    sessionKey: "migration-1",
    sessionId: "migration-session-1",
    runId: "run-blackbox-1",
  };
  const protectedAttachment = Buffer.from("PROTECTED-IMAGE-BYTES");
  const protectedModelImage = Buffer.from("MODEL-DELIVERED-IMAGE-BYTES");
  const persistedWebchatImage = Buffer.from("PERSISTED-WEBCHAT-IMAGE-BYTES");
  const persistedWebchatName = "9c8cc55d-af35-49ce-9bc2-530573d50c5f.png";
  writeFileSync(path.join(mediaRoot, "inbound", persistedWebchatName), persistedWebchatImage);
  const protectedAttachmentPath = path.join(mediaRoot, "protected-run.png");
  writeFileSync(protectedAttachmentPath, protectedAttachment);
  await controlPlane.hooks.get("message_received")(
    {
      content: "image evidence",
      sessionKey: blackboxCtx.sessionKey,
      runId: blackboxCtx.runId,
      metadata: { mediaPath: protectedAttachmentPath, mediaType: "image/png" },
    },
    blackboxCtx,
  );
  await controlPlane.hooks.get("before_model_resolve")(
    {
      runId: "run-blackbox-1",
      prompt: "Remember my terminal preference.",
      historyMessages: [],
      imagesCount: 1,
      tools: [{ name: "memory_remember" }],
    },
    blackboxCtx,
  );
  await controlPlane.hooks.get("llm_input")(
    {
      runId: "run-blackbox-1",
      sessionId: "migration-session-1",
      provider: "openai",
      model: "gpt-test",
      systemPrompt: "private system prompt",
      prompt: "Remember my terminal preference.",
      historyMessages: [],
      imagesCount: 1,
      messages: [{
        role: "user",
        content: [{
          type: "input_image",
          image_url: `data:image/png;base64,${protectedModelImage.toString("base64")}`,
        }],
      }],
      tools: [{ name: "memory_remember" }],
    },
    blackboxCtx,
  );
  const captureOnly = await safeBefore(
    { prompt: "Remember that my preferred terminal is Ghostty." },
    blackboxCtx,
  );
  assert.equal(captureOnly, undefined);
  await controlPlane.hooks.get("before_tool_call")(
    {
      toolName: "memory_search",
      toolCallId: "blackbox-tool-1",
      runId: "run-blackbox-1",
      params: { query: "terminal" },
    },
    blackboxCtx,
  );
  await controlPlane.hooks.get("after_tool_call")(
    {
      toolName: "memory_search",
      toolCallId: "blackbox-tool-1",
      runId: "run-blackbox-1",
      params: { query: "terminal" },
      result: { found: true, private: "not stored except as a digest" },
      durationMs: 5,
    },
    blackboxCtx,
  );
  await controlPlane.hooks.get("llm_output")(
    {
      runId: "run-blackbox-1",
      sessionId: "migration-session-1",
      provider: "openai",
      model: "gpt-test",
      assistantTexts: ["I remembered your terminal preference."],
      usage: { input: 10, output: 6, total: 16 },
    },
    blackboxCtx,
  );
  await safeEnd({
    runId: "run-blackbox-1",
    success: true,
    messages: [{
      role: "user",
      content: "what is this",
      idempotencyKey: "run-blackbox-1:user",
      __openclaw: {
        media: [{
          url: `media://inbound/${persistedWebchatName}`,
          contentType: "image/png",
          kind: "image",
          sizeBytes: persistedWebchatImage.length,
        }],
      },
    }],
  }, blackboxCtx);
  const migrationStatus = controlCli("status", "--state", migrationState);
  assert.equal(migrationStatus.mode, "shadow");
  assert.equal(migrationStatus.changes_model_context, false);
  const flight = blackboxCli("verify", "run-blackbox-1", "--state", migrationState);
  assert.equal(flight.timeline_chain_valid, true);
  assert.equal(flight.structurally_complete, true);
  assert.equal(flight.verdict, "completed_successfully");
  assert.equal(
    flight.timeline.filter((entry) => entry.event_type === "turn.input").length,
    1,
    "before_model_resolve and before_prompt_build must observe one turn input",
  );
  const serializedFlight = JSON.stringify(flight);
  assert.doesNotMatch(serializedFlight, /private system prompt/);
  assert.doesNotMatch(serializedFlight, /I remembered your terminal preference/);
  const evidenceCredentials = evidenceCli(
    "create-test-accounts", "--state", migrationState,
  );
  const investigatorToken = evidenceCredentials.accounts.find(
    row => row.role === "investigator",
  ).token;
  const protectedRun = evidenceCli(
    "show", "--state", migrationState, "--token", investigatorToken, "run-blackbox-1",
  );
  const protectedSerialized = JSON.stringify(protectedRun);
  assert.match(protectedSerialized, /private system prompt/);
  assert.match(protectedSerialized, /I remembered your terminal preference/);
  assert.match(protectedSerialized, /"query":"terminal"/);
  assert.match(protectedSerialized, /"found":true/);
  assert.match(protectedSerialized, new RegExp(protectedAttachment.toString("base64")));
  assert.match(protectedSerialized, new RegExp(protectedModelImage.toString("base64")));
  assert.match(protectedSerialized, new RegExp(persistedWebchatImage.toString("base64")));
  assert.match(protectedSerialized, /"artifact_capture":"encrypted_exact"/);
  assert.match(protectedSerialized, /"representation":"model_input"/);

  // External CLI harnesses such as OpenClaw's claude-cli path can skip
  // before_model_resolve while still invoking the prompt, model, and terminal
  // hooks. before_prompt_build must provide the same authenticated turn-input
  // observation and source staging without requiring a host-side workaround.
  const claudeCliCtx = {
    sessionKey: "claude-cli-session",
    sessionId: "claude-cli-session",
    runId: "run-claude-cli-fallback",
  };
  await safeBefore(
    { prompt: "Recall my governed terminal preference." },
    claudeCliCtx,
  );
  await controlPlane.hooks.get("llm_input")(
    {
      runId: "run-claude-cli-fallback",
      sessionId: "claude-cli-session",
      provider: "anthropic",
      model: "claude-cli-test",
      systemPrompt: "private cli system prompt",
      prompt: "Recall my governed terminal preference.",
      historyMessages: [],
      imagesCount: 0,
      tools: [],
    },
    claudeCliCtx,
  );
  await controlPlane.hooks.get("llm_output")(
    {
      runId: "run-claude-cli-fallback",
      sessionId: "claude-cli-session",
      provider: "anthropic",
      model: "claude-cli-test",
      assistantTexts: ["Your governed preference is available."],
      usage: { input: 12, output: 7, total: 19 },
    },
    claudeCliCtx,
  );
  await safeEnd(
    {
      runId: "run-claude-cli-fallback",
      success: true,
      messages: [],
    },
    claudeCliCtx,
  );
  const claudeCliFlight = blackboxCli(
    "verify",
    "run-claude-cli-fallback",
    "--state",
    migrationState,
  );
  assert.equal(claudeCliFlight.structurally_complete, true);
  assert.equal(claudeCliFlight.verdict, "completed_successfully");
  assert.equal(
    claudeCliFlight.timeline.filter((entry) => entry.event_type === "turn.input").length,
    1,
  );
  // Real bridge hooks → RPC persistence → projection: equivalent host envelopes.
  const progressDetails = { revision: 3, steps: { completed: 3, total: 3 } };
  const progressResult = { content: [
    { type: "text", text: "Progress card updated (rev 3, 3/3 done)" },
    { type: "text", text: JSON.stringify(progressDetails, null, 2) },
  ], details: progressDetails };
  for (const result of [progressResult, progressResult.content.map(v => ({ ...v, type: "input_text" }))]) {
    const event = { toolName: "progress_card", toolCallId: "progress-dual", runId: "run-progress-dual", params: { plan: [] } };
    const ctx = { ...blackboxCtx, runId: event.runId };
    await controlPlane.hooks.get("before_tool_call")(event, ctx);
    await controlPlane.hooks.get("after_tool_call")({ ...event, result }, ctx);
  }
  const progressFlight = blackboxCli("verify", "run-progress-dual", "--state", migrationState);
  assert.deepEqual(progressFlight.tools.conflicting_completions, []);
  assert.equal(progressFlight.tools.coalesced_wrapper_calls[0].comparison_profile, "openclaw-progress-card-v1");
  assert.equal(new Set(progressFlight.timeline.filter(e => e.event_type === "tool.completed").map(e => e.payload.result_sha256)).size, 2);
  // A host exception without a result must retain its diagnostic separately.
  await controlPlane.hooks.get("after_tool_call")({
    toolName: "web_fetch", toolCallId: "fetch-error", runId: "run-fetch-error",
    params: {}, error: "Fetch failed (403): https://private.example/?token=secret\nprivate stack", durationMs: 305,
  }, { ...blackboxCtx, runId: "run-fetch-error" });
  const errorFlight = blackboxCli("verify", "run-fetch-error", "--state", migrationState);
  const failure = errorFlight.timeline.find(entry => entry.event_type === "tool.completed").payload;
  assert.equal(failure.outcome, "error");
  assert.equal(failure.error_reason, "Fetch failed (403): [redacted-url]");
  assert.equal(failure.result_present, false);
  assert.match(failure.error_sha256, /^[0-9a-f]{64}$/);
  assert.equal(errorFlight.tools.errors[0].error_reason, failure.error_reason);
  assert.doesNotMatch(JSON.stringify(errorFlight), /private.example|private stack|token=secret/);
  for (const service of controlPlane.services) await service.stop?.();

  // Managed active mode uses the normal memory engine and a separate private
  // control process for Black Box evidence. Recording must survive cutover.
  const activeRecorder = fakeApi({
    ...base,
    takeoverActive: true,
    nativeWorkspace: path.join(dataDir, "openclaw-workspace"),
    controlPlane: {
      enabled: false,
      statePath: migrationState,
      blackboxEnabled: true,
    },
  });
  const activeCtx = {
    sessionKey: "active-session",
    sessionId: "active-session",
    runId: "run-blackbox-active",
  };
  await activeRecorder.hooks.get("before_model_resolve")(
    { prompt: "Check the active recorder.", attachments: [] },
    activeCtx,
  );
  await activeRecorder.hooks.get("before_prompt_build")(
    { prompt: "Check the active recorder.", messages: [] },
    activeCtx,
  );
  await activeRecorder.hooks.get("llm_input")(
    {
      runId: "run-blackbox-active",
      sessionId: "active-session",
      provider: "openai",
      model: "gpt-test",
      prompt: "Check the active recorder.",
      systemPrompt: "private active system prompt",
      historyMessages: [],
      imagesCount: 0,
      tools: [],
    },
    activeCtx,
  );
  await activeRecorder.hooks.get("before_tool_call")(
    {
      toolName: "memory_search",
      toolCallId: "active-tool-1",
      runId: "run-blackbox-active",
      params: { query: "recorder" },
      derivedPaths: ["/private/example/path"],
    },
    activeCtx,
  );
  await activeRecorder.hooks.get("after_tool_call")(
    {
      toolName: "memory_search",
      toolCallId: "active-tool-1",
      runId: "run-blackbox-active",
      params: { query: "recorder" },
      result: { found: true },
      durationMs: 4,
    },
    activeCtx,
  );
  await activeRecorder.hooks.get("llm_output")(
    {
      runId: "run-blackbox-active",
      sessionId: "active-session",
      provider: "openai",
      model: "gpt-test",
      assistantTexts: ["The active recorder is working."],
      usage: { input: 8, output: 5, total: 13 },
    },
    activeCtx,
  );
  await activeRecorder.hooks.get("agent_end")(
    { runId: "run-blackbox-active", success: true, messages: [], durationMs: 9 },
    activeCtx,
  );
  const activeFlight = blackboxCli(
    "verify",
    "run-blackbox-active",
    "--state",
    migrationState,
  );
  assert.equal(activeFlight.structurally_complete, true, JSON.stringify(activeFlight));
  assert.equal(activeFlight.verdict, "completed_successfully");
  assert.doesNotMatch(JSON.stringify(activeFlight), /private\/example\/path/);
  for (const service of activeRecorder.services) await service.stop?.();

  // Persistent agents sharing an exact workspace share one subject. Agents
  // with distinct (including nested) workspaces remain isolated at every
  // direct tool boundary.
  const multiConfig = {
    ...base,
    defaultAgentId: "main",
    agentSubjects: {
      main: "workspace-shared",
      helper: "workspace-shared",
      research: "workspace-research",
      nested: "workspace-nested",
    },
    agentWorkspaces: {
      main: "/workspace",
      helper: "/workspace",
      research: "/research",
      nested: "/workspace/projects/nested",
    },
  };
  const seed = new AtmemClient({
    command: "atmem",
    args: ["mcp", "--db", dbPath, "--subject", "unused-default"],
  });
  await seed.callTool("memory_remember", {
    subject_id: "workspace-shared",
    message: "Remember that the shared agent codeword is ALPHA-SHARED.",
    source_type: "user_message",
  });
  await seed.callTool("memory_remember", {
    subject_id: "workspace-research",
    message: "Remember that the research agent codeword is CHARLIE-RESEARCH.",
    source_type: "user_message",
  });
  const mainAgent = fakeApi(multiConfig, { agentId: "main", sessionKey: "agent:main:tool" });
  const helperAgent = fakeApi(multiConfig, { agentId: "helper", sessionKey: "agent:helper:tool" });
  const researchAgent = fakeApi(multiConfig, { agentId: "research", sessionKey: "agent:research:tool" });
  const mainSearch = await mainAgent.tools.get("atmem_search").execute("multi-main", { query: "ALPHA-SHARED" });
  const helperSearch = await helperAgent.tools.get("atmem_search").execute("multi-helper", { query: "ALPHA-SHARED" });
  const researchSearch = await researchAgent.tools.get("atmem_search").execute("multi-research", { query: "CHARLIE-RESEARCH" });
  assert.match(mainSearch.content[0].text, /ALPHA-SHARED/);
  assert.match(helperSearch.content[0].text, /ALPHA-SHARED/);
  assert.doesNotMatch(mainSearch.content[0].text, /CHARLIE-RESEARCH/);
  assert.match(researchSearch.content[0].text, /CHARLIE-RESEARCH/);
  assert.doesNotMatch(researchSearch.content[0].text, /ALPHA-SHARED/);
  const unknownAgent = fakeApi(multiConfig, { agentId: "unknown" });
  await assert.rejects(
    unknownAgent.tools.get("atmem_search").execute("multi-unknown", { query: "codeword" }),
    /unmapped OpenClaw persistent agent/,
  );
  for (const instance of [mainAgent, helperAgent, researchAgent, unknownAgent]) {
    for (const service of instance.services) await service.stop?.();
  }
  seed.close();

  console.log(
    "hooks: direct engine and fail-closed memory control plane paths verified",
  );
} finally {
  for (const service of runtime.services) await service.stop?.();
  rmSync(dataDir, { recursive: true, force: true });
}
