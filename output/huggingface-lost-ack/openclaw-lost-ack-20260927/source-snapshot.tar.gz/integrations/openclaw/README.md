# AtMem OpenClaw bridge

This npm package is the host bridge for AtMem. It is not a standalone memory engine and should not be installed directly.

The source tree targets prerelease bridge `2.3.7-beta.2` for AtMem `2.3.7b2`.
Install or upgrade through the matching AtMem Python package.

Use the Python-owned installer:

```bash
python -m pip install --pre --upgrade atmem==2.3.7b2
atmem openclaw install
```

The installer pins the matching OpenClaw bridge, binds the exact `atmem` executable, copies existing OpenClaw memory, configures shadow mode, restarts the gateway and verifies the loaded plugin. Direct npm installation cannot perform or prove those steps.

The bridge also supports AtMem's optional delegated context-provider mode. It
supplies authenticated owner/workspace bindings, contributes a verified result
as exactly one `prependContext` segment, confirms that segment at `llm_input`,
and suppresses native AtMem recall for the turn. Delegation is enabled only by
an AtMem registration; the bridge's `delegatedContext.userId` is an identity
mapping, not an activation switch.

Existing AtMem 2.1 users run `atmem openclaw upgrade` after upgrading the Python
package. This preserves the current memory mode and migration, verifies the new
bridge with a self-test flight, and rolls back the bridge on failure.

The bridge retains the reviewed compatibility updates from 2.3.4-beta.1, including exact task-context delivery and the shared
calibrated retrieval decision, and delegated context correlation. When the host
supplies `taskId` in hook context, the bridge requests only that governed task,
checks its byte digest, contributes it separately from recalled memory, and
confirms exposure. With no `taskId`, task delivery stays off and existing
memory-only behavior is unchanged. Guard detection is available, but this
bridge does not claim it can block OpenClaw execution.

In shadow mode the bridge observes native-memory changes without injecting AtMem context. In active mode it exposes compatible memory search/get tools, model-semantic capture, bounded recall and native-path protection. `atmem control restore` restores the saved OpenClaw configuration and native memory.

The bridge also supplies Agent Black Box hooks. With default full capture it sends
exact host-observed prompts, model boundaries, tool arguments/results and supported
multimodal parts into AtMem's encrypted evidence vault, alongside digest-bound
lifecycle metadata. Metadata-only and recorder-off modes remain explicit operator
choices. See the [Agent Black Box guide](../../docs/agent-blackbox.md) for the exact boundary.

See the repository [OpenClaw setup](../../docs/openclaw-setup.md) and [control-plane guarantees](../../docs/control-plane.md).


### Delegated local CLI identity and tool evidence in 2.2.6

The default delegated user mapping requires `senderIsOwner: true`. Setting
`requireOwner: false` alone no longer bypasses identity checks. A dedicated local
CLI process can use the explicit [isolated mapping configuration](../../docs/delegated-context-provider.md#isolated-local-cli-identity-226)
with matching workspace, agent and exact session generation. If CLI origin is
absent, an explicitly configured private state directory and an unrouted
`agent --local` process with no configured shared channels establish the local
process boundary. Shared-channel and explicit non-owner turns are refused.

Tool completion hooks use the event's invocation ID or, when absent, the host
context's ID. The verifier requires matching tool, turn and scope and a request
preceding completion. Missing completion observations remain `incomplete_evidence`;
actual terminal host tool-event results supply fallback observations when typed
completion hooks are absent. Only matched requests close, with content-free
bounded caching and duplicate suppression. Fully observed
terminal tool errors close evidence as `completed_with_tool_errors`, not success.

Local development follow-up: automatic recall now requires calibrated direct
query support by default (`recall.requireDirectSupport: true`). Persona is an
explicit opt-in (`persona.enabled: true`); setup defaults it off to avoid adding
unrelated personal facts to every request. When enabled, persona records are
excluded from recall so each appears once. Existing explicit persona settings
are respected; set `persona.enabled: false` to adopt selective recall. Explicit
memory search remains available. The legacy rank-only mode is available with
`recall.requireDirectSupport: false`; it can admit weak matches.
